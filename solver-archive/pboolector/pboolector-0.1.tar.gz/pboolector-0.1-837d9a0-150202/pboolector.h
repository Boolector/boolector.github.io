/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */
#ifndef PBOOLECTOR_H_INCLUDED
#define PBOOLECTOR_H_INCLUDED

#include "boolector.h"

BoolectorNode * boolector_lookahead (Btor * btor, int v, int type, int pr,  
                     BtorPtrHashTable * remset);
BoolectorNode * boolector_lookahead_simple (Btor * btor);
int boolector_failed_literal_reduction(Btor * btor, int v, int* fl);
int boolector_get_size (Btor *btor);
int boolector_get_vars (Btor * btor);
BoolectorNode * boolector_get_exp_by_id (Btor * btor, int id);
int boolector_is_bcond_exp(Btor *btor, BoolectorNode * node);
int boolector_is_mul_exp(Btor *btor, BoolectorNode * node);
int boolector_is_add_exp(Btor *btor, BoolectorNode * node);
BoolectorNode * boolector_get_param0(Btor* btor, BoolectorNode* node);
BoolectorNode * boolector_get_param1(Btor * btor, BoolectorNode * node);
int boolector_is_exp_assert_eq_ne_zero (Btor * btor, BoolectorNode * node);
int boolector_is_exp_assert_eq_ne_one (Btor * btor, BoolectorNode * node);
int boolector_fixed_exp_at(Btor* btor, BoolectorNode * node, int pos);
size_t boolector_bytes(Btor* btor);
double boolector_get_sat_time(Btor* btor);
void boolector_disable_sat_inc_required(Btor* btor);
void boolector_set_term_sat (Btor* btor, int (*term)(void*));

#endif
