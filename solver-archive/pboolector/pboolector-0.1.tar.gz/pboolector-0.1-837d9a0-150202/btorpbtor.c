/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */

// for debuggung to check different paralleisation APIS
#define PARALLEL 0
#define SEQUENTIAL 1
#define DEBUG1 2 
#define DEBUG2 3 
#define DEBUG3 4
#define OMP 5
// always use PARALLEL when not debugging
#define RUNMODE PARALLEL

#define LKHDSPLITPAR        // do lookahead and split in parallel with pthread

#include "btorparse.h"
#include "btorsat.h"
#include "btorhash.h"
#include "pboolector.h"
#include "btoraig.h"
#include "btorlkhd.h"
#include "btorpbtor.h"
#include "parser/btorbtor.h"
#include "parser/btorsmt2.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <limits.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#include <float.h>
#include <math.h>
#include <ctype.h>

#if RUNMODE==OMP
#include <omp.h>
#endif

#include "btormem.h"

#include <sys/time.h>
#include "sys/types.h"
#include "sys/sysinfo.h"

/*------------------------------------------------------------------------*/

int
btor_fixed_exp_at (Btor * btor, BtorNode * exp, int pos)
{
  BtorNode * real_exp;
  BtorSATMgr * smgr;
  BtorAIGMgr *amgr;
  BtorAIG * aig;
  int res, id;

  real_exp = BTOR_REAL_ADDR_NODE (exp);
  assert (pos >= 0 && pos < real_exp->len);
  if (! BTOR_IS_SYNTH_NODE (real_exp))
    return 0;
  assert (real_exp->av);
  assert (real_exp->av->len == real_exp->len);
  assert (real_exp->av->aigs);
  aig = real_exp->av->aigs[pos];
  if (aig == BTOR_AIG_TRUE)
    res = 1;
  else if (aig == BTOR_AIG_FALSE)
    res = -1;
  else
    {
      id = BTOR_GET_CNF_ID_AIG (aig);
      if (!id)
        return 0;
      amgr = btor_get_aig_mgr_aigvec_mgr (btor->avmgr);
      smgr = btor_get_sat_mgr_aig_mgr (amgr);
      res = btor_fixed_sat (smgr, id);
    }
  if (BTOR_IS_INVERTED_NODE (exp))
    res = -res;
  return res;
}

/*------------------------------------------------------------------------*/
#define LL long long

#define WORKERSTOMAXACTIVE(workers) workers * 4

#define LMIN 1000
#define LMAX 50000

static int verbosity;
static int lkhdvrb = 0;
static int btorvrb = 0;
static int limit;
static int fullint = 10;
static int maxactive;
static int lmin;
static int lmax;
static int initiallkhd = 0;
static int pr = 0;
static int flr = 0;

static int lkhdtype = 0;

/*------------------------------------------------------------------------*/

#define MAXGB                        12ll        //TODO why ll
#define MAXBYTES                (MAXGB<<30)

/*------------------------------------------------------------------------*/

#define NEW(PTR,NUM) \
do { \
  size_t BYTES = (NUM) * sizeof *(PTR); \
  (PTR) = malloc (BYTES); \
  if (!(PTR)) { err (ms, "out of memory"); exit (1); } \
  memset ((PTR), 0, BYTES); \
  incmem (BYTES); \
} while (0)

#define DEL(PTR,NUM) \
do { \
  size_t BYTES = (NUM) * sizeof *(PTR); \
  decmem (BYTES); \
  free (PTR); \
} while (0)

#define PUSH(STACK,ELEM) \
do { \
  if (size ## STACK == num ## STACK) { \
    size_t NEW_SIZE = size ## STACK; \
    size_t OLD_BYTES = NEW_SIZE * sizeof *STACK, NEW_BYTES; \
    if (NEW_SIZE) NEW_SIZE *= 2; else NEW_SIZE = 1; \
    NEW_BYTES = NEW_SIZE * sizeof *STACK; \
    decmem (OLD_BYTES); \
    STACK = realloc (STACK, NEW_BYTES); \
    if (!STACK) { err (ms, "out of memory"); exit (1); } \
    incmem (NEW_BYTES); \
    size ## STACK = NEW_SIZE; \
  } \
  STACK[num ## STACK ++] = (ELEM); \
} while (0)

/*------------------------------------------------------------------------*/

static size_t getotalmem ()
{
    struct sysinfo memInfo;
    sysinfo (&memInfo);
    return memInfo.totalram;    
}

static size_t getmemusage ()
{
    struct sysinfo memInfo;
    sysinfo (&memInfo);
    return memInfo.totalram - memInfo.freeram;
}

static int getcores() {
  int syscores;
  
  syscores = sysconf (_SC_NPROCESSORS_ONLN);
  assert (syscores > 0);
  return syscores;
} 

int bytes2mb (size_t bytes) {
  size_t res = bytes;
  res >>= 20;
  if (res > INT_MAX) res = INT_MAX;
  return res;
}

/*------------------------------------------------------------------------*/
//TODO use int64_t for id

typedef struct Msg {
  char* prefix;
  int verbosity;
  double startime;
} Msg;

// time statistic for one node
typedef struct NStat {
  int round, id, depth, finished, closed;
  int sred, vred;         //size/var reduction
  double time, sat_time;
} NStat;

typedef enum State { 
  READY = 0,
  SIMP = 1,
  LKHD = 2,
  SPLIT = 3,
  SEARCH = 4,
} State;

typedef struct Node {
  State state;
  int pos, depth, res, finish;
  int searched, split;  //assert dbg  
  int64_t id;
  BoolectorNode *lookahead;
  Btor * btor;
  BtorPtrHashTable * remset;
} Node;

typedef struct Job {
  //int pos;
  //State state;
  Node * node;
  void* (*fun)(void *);
  pthread_t thread;
  //const char * name;
} Job;

typedef struct Lock {
  pthread_mutex_t mutex;
  int locked, waited;
} Lock;

typedef struct Parallel {
  int res;
  Btor *btor;
  pthread_t thread;
} Parallel;


static void lockmsg ();
static void unlockmsg ();

// timer
/*------------------------------------------------------------------------*/

static double 
currentime () {
  double res = 0;
  struct timeval tv;
  if (!gettimeofday (&tv, 0))
    res = 1e-6 * tv.tv_usec, res += tv.tv_sec;
  return res;
}

static double 
getime (Msg *msg) { return currentime () - msg->startime; }

static int started;
static double * startimeptr, startime;

static void 
startimer (double *timeptr) 
{
  assert (!started);
  assert (!startimeptr);
  startimeptr = timeptr;
  startime = currentime();
  started = 1;
}

static double 
deltatime (double start) {
  double res = currentime () - start;
  assert (res >=0 );
  return res;
}

static void 
stoptimer () {
  assert (started);
  assert (startimeptr);
  *startimeptr += deltatime (startime);
  started = 0; 
  startimeptr = 0;
}

// utilities
/*------------------------------------------------------------------------*/

static char *
resToName (int res) 
{
  if (res == BOOLECTOR_SAT) {
    return "SAT";
  } else if (res == BOOLECTOR_UNSAT) {
    return "UNSAT";
  } else 
  {
    assert (!res);
    return "UNKNOWN";
  }
}

static int 
isnum (const char * str) 
{
  const char * p = str;
  if (!isdigit (*p) && !(*p) == '-') return 0;
  while (*++p) if (!isdigit (*p)) return 0;
  return 1;
}

static void 
statvals (NStat** nstats, int numnstats, double* mean, double *std, 
               double *min, double *max, double *sum, double *satsum)
{
  int i;
  *mean = 0.0;
  *std = 0.0;
  *min = DBL_MAX;
  *max = 0.0;
  *sum = 0.0;
  *satsum = 0.0;
  
  if (numnstats > 0)
  {  
    //mean 
    for (i = 0; i < numnstats; i++)
    {
      *sum += nstats[i]->time;
      *satsum += nstats[i]->sat_time;
      if (*min > nstats[i]->time) *min = nstats[i]->time;
      if (*max < nstats[i]->time) *max = nstats[i]->time;
    }
    *mean = *sum / numnstats;
    if (numnstats > 1)
    {
      int sum = 0.0;
      for (i = 0; i < numnstats; i++)
        sum += (*mean - nstats[i]->time) * (*mean - nstats[i]->time);
      *std = sqrt(sum/(numnstats - 1));
    }
  }
  
  if (*min == DBL_MAX) 
  {
    assert(*max == 0.0);
    *min = 0.0;
  }
}

// messages
/*------------------------------------------------------------------------*/

static Msg * 
newmsg(char *prefix) 
{
  Msg * msg;
  msg = malloc (sizeof(Msg));
  msg->prefix = prefix;
  msg->verbosity = 0;
  msg->startime = currentime();
  return msg;
}

static void
delmsg(Msg* msg)
{
  free(msg), msg = 0;
}

static int 
vrb (Msg *msg) 
{
  return msg->verbosity;
}

static void
setvrb(Msg* msg, int v)
{
  assert (v >= -1 && v <= 4);
  msg->verbosity = v;
}

static void
msg (Msg *msg, int level, char *fmt, ...)
{
  assert (msg);
  if (level <= msg->verbosity) {
    lockmsg();
    assert (fmt);
    double t = getime(msg);
    va_list list;
    va_start (list, fmt);
    fprintf (stdout, "[%s] %d - %.4f ", msg->prefix, level, t);
    if (level == 4) fprintf (stdout, "*** ");
    vfprintf (stdout, fmt, list);
    va_end (list);
    fflush(stdout);
    unlockmsg();
  }
}

/*
// message without prefix
static void
msgwop (Msg *msg, int level, char *fmt, ...)
{
  assert (msg);
  if (level <= msg->verbosity) {
    lockmsg();
    assert (fmt);
    va_list list;
    va_start (list, fmt);
    vfprintf (stdout, fmt, list);
    va_end (list);
    fflush(stdout);
    unlockmsg();
  }
}
*/

static void 
nmsg (Msg *msg, int level, Node *node, char *fmt, ...)
{
  assert (msg);
  if (level <= msg->verbosity) {
    lockmsg();
    assert (fmt);
    assert (node);
    double t = getime(msg);
    fprintf (stdout, "[%s] %d - %.4f ", msg->prefix, level, t);
    fprintf (stdout, "[%d](%lld %d %d (%d-%d) %s) ",
             node->pos, (LL) node->id, node->depth, node->searched,
             boolector_get_size(node->btor),
             boolector_get_vars(node->btor),
             resToName(node->res));
    va_list list;
    va_start (list, fmt);
    vfprintf (stdout, fmt, list);
    va_end (list);
    fflush(stdout);
    unlockmsg();
  }
}

void nsmsg (Msg *msg, int level, Node **nodes, int n, char *fmt, ...) {
  assert (msg);
  if (level <= msg->verbosity)
  {
    lockmsg();
    assert (nodes);
    assert (fmt);
    int i;
    double t = getime(msg);
    fprintf (stdout, "[%s] %d - %.4f ---------------------------\n", 
             msg->prefix, level, t);
    fprintf (stdout, "[%s] %d - %.4f ", msg->prefix, level, t);
    va_list list;
    va_start (list, fmt);
    vfprintf (stdout, fmt, list);
    va_end (list);
    for (i = 0; i < n; i++)
    {
      unlockmsg();
      nmsg(msg, level, nodes[i], "\n");
      lockmsg();
    }
    fprintf (stdout, "[%s] %d - %.4f ---------------------------\n", 
             msg->prefix, level, t);
    unlockmsg();
  }
}

void 
err (Msg *ms, const char * err, ...) {
  va_list ap;
  // TODO use stderr?
  lockmsg();
  fprintf (stdout, "*** [%s] ", ms->prefix);
  va_start (ap, err);
  vprintf (err, ap);
  va_end (ap);
  fprintf (stdout, "\n");
  fflush (stdout);
  delmsg(ms);
  unlockmsg();
  exit (1);
}

/*------------------------------------------------------------------------*/

static Msg *ms;

int64_t ids;

static size_t maxbytes, currentbytes, hardlimbytes, softlimbytes;;

static Node ** nodes;
static int numnodes, sizenodes;

static Job ** jobs;
static int numjobs, sizejobs;
//static int numjobs_1;

static int rounds, added, deleted, finished, fintotal;
static int maxnodes;
static int maxrounds;

static int numworkers, maxnumworkers;

static struct { double simp, lkhd, split, search, flr; } wct;

// simp statistics
static NStat ** sistats;
static int numsistats, sizesistats;
// lkhd statistics
static NStat ** lkhdstats;
static int numlkhdstats, sizelkhdstats;
// split statistics
static NStat ** spstats;
static int numspstats, sizespstats;
// search statistics
static NStat ** sestats;
static int numsestats, sizesestats;

static BtorMemMgr *mm;

static Parallel pinstance;
static int startpar;

static int ninc, nfin;

static int done;

static struct { 
  Lock mem, stat, workers, done, msg;
} lock;

static pthread_cond_t workerscond;

/*------------------------------------------------------------------------*/

static void lockgen (Lock * lock, const char * name) {
  if (pthread_mutex_lock (&lock->mutex))
    err (ms, "failed to lock '%s' mutex", name);
  assert (!lock->locked || lock->waited);
  lock->locked++;
}

static void unlockgen (Lock *lock, const char * name) {
  assert (lock->locked > 0 || lock->waited);
  lock->locked--;
  if (pthread_mutex_unlock (&lock->mutex))
    err (ms, "failed to lock '%s' mutex", name);
}

#define LOCK(NAME) do { lockgen (&lock.NAME, # NAME); } while (0)
#define UNLOCK(NAME) do { unlockgen (&lock.NAME, # NAME); } while (0)

static void lockworkers () { LOCK (workers); }
static void lockstat () { LOCK (stat); }
static void lockmem () { LOCK (mem); }
static void lockdone () { LOCK (done); }
static void lockmsg () { LOCK (msg); }

static void unlockworkers () { UNLOCK (workers); }
static void unlockstat () { UNLOCK (stat); }
static void unlockmem () { UNLOCK (mem); }
static void unlockdone () { UNLOCK (done); }
static void unlockmsg () { UNLOCK (msg); }

/*------------------------------------------------------------------------*/


static double avg (double a, double b) { return b > 0 ? a/b : 0.0; }

/*------------------------------------------------------------------------*/

/* Computes hash value of absolute value of id */
unsigned int
hash_int_by_abs (int * id)
{
  assert (id);
  return (unsigned int) abs(*id) * 7334147u;
}

/* Compare by absolute value of id */
int
compare_int_by_abs (int * id0, int * id1)
{
  int aid0, aid1;
  assert (id0);
  assert (id1);
  aid0 = abs(*id0);
  aid1 = abs(*id1);
  if (aid0 < aid1)
    return -1;
  if (aid0 > aid1)
    return 1;
  return 0;
}

static int term_sat (void* dummy) {
  int res;
  assert (!dummy);
  lockdone();
  res = done;
  //if (res)
    //msg (ms, 0, "term = %d\n", res);
  unlockdone();
  return res;
}

static void
joinparallel (int res) {
  //TODO join parallel solver here
  msg (ms, 0, "joining parallel instance\n");
  lockdone();
  assert(res);
  done = res;
  unlockdone();
  
  if (pthread_join (pinstance.thread, 0))
    err (ms, "failed to join additional parallel solver instance thread");
}

static void * runparallel(void * arg) {
  assert (!arg);  //just allow NULL arg
  int res;
  
  if ((res = boolector_sat(pinstance.btor))) {
    lockdone();
    pinstance.res = res;
    done = res;
    unlockdone();
  }
  
  boolector_delete(pinstance.btor);
  
  msg (ms, 1, "parallel boolector instance finished with res=%d\n", res);
  
  return arg;
}

static void
startparallel () {
  //start parallel solver here
  assert (numnodes == 1);
  assert (nodes[0]->btor);
    
  msg (ms, 0, "cloning and starting parallel boolector instance\n");
  
  pinstance.btor = boolector_clone (nodes[0]->btor);
  //btor is in non inc usage here no need to set non_inc_usage
  //set sat solver non inc usage
  //boolector_disable_sat_inc_required(pinstance.btor);
  boolector_set_term_sat(pinstance.btor, term_sat);
  
  if (pthread_create (&pinstance.thread, 0, runparallel, 0))
    err (ms, "failed to create thread for additional parallel solver instance");
}

static size_t countbytes () {
  size_t bytes = currentbytes;
  Node * node;
  int i;
  for (i = 0; i < numnodes; i++) {
    node = nodes[i];
    assert (node);
    bytes += boolector_bytes(node->btor);
  }
  return bytes;
}

static int full () {
  return fullint && !(rounds % fullint);
}

static int firstlkhd();

static void varsizespan (int * minvarsptr, int * maxvarsptr, 
                         int * actsizeptr, int * actvarsptr,
                         int *minsizeptr, int * maxsizeptr)
{
  int i, vars, minvars, maxvars, size, minsize, maxsize;
  Node * node;
  minvars = INT_MAX, minsize = INT_MAX;
  maxvars = 0, maxsize = 0;
  
  //assert (numnodes > 0);
  
  for (i = 0; i < numnodes; i++) 
  {
    node = nodes[i]; 
    assert (node);
    assert (node->btor);
    
    // TODO count skipped node??
    // TODO long int vars?
    vars = boolector_get_vars (node->btor); 
    size = boolector_get_size (node->btor);
    if (minvars > vars) minvars = vars;
    if (maxvars < vars) maxvars = vars;
    if (minsize > size) minsize = size;
    if (maxsize < size) maxsize = size;
  }
  if (minvars == INT_MAX) 
  {
    assert (!maxvars);
    minvars = 0;
  }
  if (minsize == INT_MAX) 
  {
    assert (!maxsize);
    minsize = 0;
  }
  
  if (numnodes > 0) {
    *actsizeptr = boolector_get_size(nodes[firstlkhd()]->btor);
    *actvarsptr = boolector_get_vars(nodes[firstlkhd()]->btor);
  } else {
    *actsizeptr = 0;
    *actvarsptr = 0;
  }
  
  *minvarsptr = minvars;
  *maxvarsptr = maxvars;
  *minsizeptr = minsize;
  *maxsizeptr = maxsize;
}

static void report () {
  int minvars, maxvars, actsize, actvars,  minsize, maxsize, isfull = full ();
  varsizespan (&minvars, &maxvars, &actsize, &actvars, &minsize, &maxsize);
  msg (ms, 0, "%c%d %lld%c %d nodes +%d -%d(%d) (%d-%d..%d-%d..%d-%d) "
        "limit %d, %dMB %dMB\n",
       (isfull ? '[' : '('), rounds, (LL) ids, (isfull ? ']' : ')'),
       numnodes, added, deleted, finished, 
       minsize, minvars, actsize, actvars, maxsize, maxvars,  limit, 
       bytes2mb(countbytes()), bytes2mb(getmemusage())
      );
  if (numnodes > maxnodes) maxnodes = numnodes;
}

static void stats () {
  int i;
  double w = getime (ms);
  double wctother = w - (wct.simp + wct.lkhd + wct.split + wct.search + wct.flr);
  
  double mean, std, min, max, sum, satsum;
    
  
  if (vrb(ms) >= 0) {
    // print indvidual time statistics
    
    // lookahead
    msg (ms, 1, "lookahead time statistic n=%d\n", numspstats);
    msg (ms, 2, "rnd  id       time\n");
    for (i = 0; i < numlkhdstats && vrb(ms) >= 2; i++) 
    {
      NStat * nstat = lkhdstats[i];
      assert (nstat);
      msg (ms, 2, "%3d %3d %10.4f\n", nstat->round, nstat->id, 
          nstat->time);
    }
    statvals(lkhdstats, numlkhdstats, &mean, &std, &min, &max, &sum, &satsum);  
    msg (ms, 1, "==========================\n");  
    msg (ms, 1, "Sum     %18.4f\n", sum);  
    msg (ms, 1, "Mean    %18.4f\n", mean);  
    msg (ms, 1, "Std     %18.4f\n", std);
    msg (ms, 1, "Min     %18.4f\n", min);  
    msg (ms, 1, "Max     %18.4f\n", max);
    
    
    // split
    msg (ms, 1, "split time statistic n=%d\n", numspstats);
    msg (ms, 2, "rnd  id       time\n");
    for (i = 0; i < numspstats && vrb(ms) >= 2; i++) 
    {
      NStat * nstat = spstats[i];
      assert (nstat);
      msg (ms, 2, "%3d %3d %10.4f\n", nstat->round, nstat->id, 
          nstat->time);
    }
    statvals(spstats, numspstats, &mean, &std, &min, &max, &sum, &satsum);  
    msg (ms, 1, "==========================\n");  
    msg (ms, 1, "Sum     %18.4f\n", sum);  
    msg (ms, 1, "Mean    %18.4f\n", mean);  
    msg (ms, 1, "Std     %18.4f\n", std);
    msg (ms, 1, "Min     %18.4f\n", min);  
    msg (ms, 1, "Max     %18.4f\n", max);
    
    //simp
    msg (ms, 1, "simp time statistic n=%d\n", numsistats);
    msg (ms, 2, "rnd  id  sred  vred       time\n");
    for (i = 0; i < numsistats && vrb(ms) >= 2;  i++) 
    {
      NStat * nstat = sistats[i];
      assert (nstat);
      msg (ms, 1, "%3d %3d %5d %5d %10.4f\n", nstat->round, nstat->id, 
          nstat->sred, nstat->vred, nstat->time);
    }
      
    statvals(sistats, numsistats, &mean, &std, &min, &max, &sum, &satsum);
    msg (ms, 1, "==========================\n");      
    msg (ms, 1, "Sum     %18.4f\n", sum);    
    msg (ms, 1, "Mean    %18.4f\n", mean);  
    msg (ms, 1, "Std     %18.4f\n", std);
    msg (ms, 1, "Min     %18.4f\n", min);  
    msg (ms, 1, "Max     %18.4f\n", max);      
    
    // search
    msg (ms, 0, "search time statistic n=%d\n", numsestats);
    msg (ms, 1, "rnd  id dep cls fin  sred  vred    time sattime\n");
    for (i = 0; i < numsestats && vrb(ms) >= 1; i++) 
    { 
      NStat * nstat = sestats[i];
      assert (nstat);
      msg (ms, 0, "%3d %3d %3d %3d %3d %5d %5d %7.4f %7.4f\n", nstat->round, 
           nstat->id, nstat->depth, nstat->closed, nstat->finished, 
           nstat->sred, nstat->vred, nstat->time, nstat->sat_time);
    }
    
    statvals(sestats, numsestats, &mean, &std, &min, &max, &sum, &satsum);
    msg (ms, 0, "==========================\n");  
    msg (ms, 0, "SatSum  %18.4f\n", satsum);      
    msg (ms, 0, "Sum     %18.4f\n", sum);    
    msg (ms, 0, "Mean    %18.4f\n", mean);  
    msg (ms, 0, "Std     %18.4f\n", std);
    msg (ms, 0, "Min     %18.4f\n", min);  
    msg (ms, 0, "Max     %18.4f\n", max);  
  }
  // summary  
  msg (ms, 0, "rounds: %d\n", rounds);
  msg (ms, 0, "maxNodes: %d\n", maxnodes);
  msg (ms, 0, "totalNodes: %d\n", ids);
  msg (ms, 0, "finishedNodes: %d\n", fintotal);
  
  msg (ms, 0, "\n");
  msg (ms, 0, "%7.2f seconds fl. red.    %4.0f%%\n", wct.flr, avg (100*wct.flr,w));
  msg (ms, 0, "%7.2f seconds lookahead   %4.0f%%\n", wct.lkhd, avg (100*wct.lkhd,w));
  msg (ms, 0, "%7.2f seconds splitting   %4.0f%%\n", wct.split, avg (100*wct.split,w));
  msg (ms, 0, "%7.2f seconds simplify    %4.0f%%\n", wct.simp, avg (100*wct.simp,w));
  msg (ms, 0, "%7.2f seconds searching   %4.0f%%\n", wct.search, avg (100*wct.search,w));
  msg (ms, 0, "%7.2f seconds other       %4.0f%%\n", wctother, avg (100*wctother,w));
  msg (ms, 0, "==================================\n");
  msg (ms, 0, "%7.2f seconds total\n", w );
}

static void 
initial () {
  rounds = 0;
  msg (ms, 1, "\n");
  msg (ms, 1, "=================== [ intial ] ===================\n");
  msg (ms, 1, "\n");
}

static void 
incrounds () {
  rounds++;
  msg (ms, 1, "\n");
  msg (ms, 1, "=================== [ round %d ] ===================\n", rounds);
  msg (ms, 1, "\n");
}

static void 
final () {
  msg (ms, 1, "\n");
  msg (ms, 1, "=================== [ final ] ===================\n");
  msg (ms, 1, "\n");
}

static void startphase (const char * phase) {
  msg (ms, 2, "\n");
  msg (ms, 2, "------------------- [ %s %d ] -------------------\n", phase, rounds);
  msg (ms ,2, "\n");
}

/*------------------------------------------------------------------------*/

static void incmem (size_t bytes) {
  lockmem ();
  currentbytes += bytes;
  if (currentbytes > maxbytes) maxbytes = currentbytes;
  unlockmem ();
}

static void decmem (size_t bytes) {
  lockmem ();
  assert (currentbytes >= bytes);
  currentbytes -= bytes;
  unlockmem ();
}

/*------------------------------------------------------------------------*/

static void incworkers () {
  lockworkers ();
  assert (numworkers <= maxnumworkers);
  while (numworkers >= maxnumworkers) {
    lock.workers.waited++;
    if (pthread_cond_wait (&workerscond, &lock.workers.mutex))
      err (ms, "failed to wait on decrease of the number of workers\n");
    lock.workers.waited--;
    assert (numworkers < maxnumworkers);
  }
  numworkers++;
  msg (ms, 3, "number of workers increased to %d\n", numworkers);
  unlockworkers ();
}

static void decworkers () {
  lockworkers ();
  assert (numworkers > 0);
  numworkers--;
  msg (ms, 3, "number of workers decreased to %d\n", numworkers);
  if (pthread_cond_signal (&workerscond))
    err (ms, "failed to signal decrease of the number of workers\n");
  unlockworkers ();
}

static void schedulejob (Node * node, void*(*fun)(void*)) {
  Job * job;
  
  NEW (job, 1);
  job->node = node;
  job->fun = fun;
  
  PUSH (jobs, job);
}

static void 
runjob (Job * job) {
  if (pthread_create(&job->thread, 0, job->fun, job->node)) {
    err (ms, "failed to create thread job");
  }
}

static void 
runjobs () {
  Job * job;
  int i;
  msg (ms, 1, "run %d scheduled jobs\n", numjobs);
  //sortjobs ();
  numworkers = 0;
  for (i = 0; i < numjobs; i++) {
    incworkers ();
    job = jobs[i];
    runjob (job);
  }
}

static void joinjob (Job * job) {
  pthread_join (job->thread, NULL);
  DEL (job, 1);
}

static void joinjobs () {
  int i;
  for (i = 0; i < numjobs; i++) 
    joinjob (jobs[i]);
  numjobs = 0;
}

static void setincusage(Btor *btor) {
  // setup sat solver and boolector inremental or non inc;
  if (!ninc) {
    boolector_set_opt(btor, "incremental", 1);
  }
}

static Node *newnode (Node *parent) {
  Node *res = NULL;
  NEW (res, 1);
  //assert (res->state == FREE);
  res->id = ids++;
  res->state = READY;
  res->pos = numnodes;
  res->remset = btor_new_ptr_hash_table(mm,
                (BtorHashPtr) hash_int_by_abs,
                (BtorCmpPtr) compare_int_by_abs);
  PUSH (nodes, res);
  if (parent)
  {
    res->depth = parent->depth + 1;
    parent->depth++;
 

#ifdef LKHDSPLITPAR   
    unlockstat(); //just unlock cloning to run paralllel
#endif
        
    res->btor = boolector_clone(parent->btor);
    
#ifdef LKHDSPLITPAR   
    lockstat(); // do the rest locked
#endif
    
    boolector_set_term_sat(res->btor, term_sat);
    
    // copy remember seten
    BtorPtrHashBucket * bu = parent->remset->first;
    while (bu) {
      int id = *((int*) bu->key);
      int *insert;
      NEW (insert, 1);
      *insert = id;
      BtorPtrHashBucket *nbu = btor_insert_in_ptr_hash_table(res->remset, insert);
      nbu->data.asInt = bu->data.asInt;      
      bu = bu->next;
    }
    
  } else {
    res->depth = 0;
    
    //setup  initial btor instance
    
    res->btor = boolector_new();  
    boolector_set_opt(res->btor, "verbosity", btorvrb);
    
    boolector_set_opt(res->btor, "rewrite_level", 3);
    
    boolector_set_term_sat(res->btor, term_sat);
  }
  added++;
  assert (res);
  return res;
}

static void delnode (Node * node) {
  Node *lastNode;
  int lastpos;
  Btor *btor;
  assert (node);
  assert (0 <= node->pos && node->pos < numnodes);
  assert (nodes[node->pos] == node);
  assert (numnodes > 0);
  lastpos = --numnodes;
  lastNode = nodes[lastpos];
  assert (lastNode && lastNode->pos == lastpos);
  if (node != lastNode)
  {
    assert (node->pos < lastpos);
    nodes[node->pos] = lastNode;
    lastNode->pos = node->pos;
  }
  nodes[lastpos] = NULL;
  btor = node->btor;
  node->btor = NULL;
  while (node->remset->count > 0) {
    int * key;
    btor_remove_from_ptr_hash_table(node->remset, node->remset->first->key, 
                                    (void **)&key, 0);
    DEL (key, 1);
  }
  btor_delete_ptr_hash_table(node->remset);
  
  DEL (node, 1);
  assert (btor);
  assert (boolector_get_refs(btor) == 0);
  boolector_delete(btor);
  deleted++;
}

static int cmpnodes (const void *p1, const void *p2)
{
  assert (p1);
  assert (p2);
  
  Node *n1 = *(Node **) p1;
  Node *n2 = *(Node **) p2;
  
  assert (n1->btor);
  assert (n2->btor);
    
  int p1elems = boolector_get_size (n1->btor);
  int p2elems = boolector_get_size (n2->btor);
  
  if (p1elems < p2elems) 
    return -1;
  else if (p1elems == p2elems) 
    return 0;
  else /*p1elems > p2elems*/ 
    return 1;
}

static void fixnodespos () {
  Node * node;
  int i;
  for (i = 0; i < numnodes; i++) {
    node = nodes[i];
    assert (node);
    node->pos = i;
  }
}

static void sortnodes ()
{  
  qsort(nodes, numnodes, sizeof *nodes, cmpnodes);
  fixnodespos();
  msg (ms, 3, "%d nodes sorted\n", numnodes);
  nsmsg (ms, 4, nodes, numnodes, "sorted nodes:\n");
}
/*------------------------------------------------------------------------*/
static void *
simpnode (void * voidptr)
{
  Node *node = voidptr;
  
  assert (node);
  assert (node->btor);
  NStat *nstat;
  
   // simp statistic
  lockstat();
  NEW(nstat, 1);
  nstat->round = rounds;
  nstat->id = node->id;
  nstat->depth = node->depth;
  int size = boolector_get_size(node->btor);
  int vars = boolector_get_vars(node->btor);
  nstat->sred = size;
  nstat->vred = vars;
  nstat->time = currentime();
  unlockstat();
    
  node->res = boolector_simplify(node->btor);
  
  
  // simp statistic
  lockstat();
  nstat->time = currentime() - nstat->time;
  nstat->sred = nstat->sred - boolector_get_size(node->btor);
  nstat->vred = nstat->vred - boolector_get_vars(node->btor);
  nstat->closed = node->res > 0;
  PUSH(sistats, nstat); 
  unlockstat();
    
  msg (ms, 3, "  reduction: from (%d-%d) to (%d-%d) = (%d-%d)\n", 
         size, vars, boolector_get_size(node->btor), 
         boolector_get_vars(node->btor), nstat->sred, nstat->vred);
  msg (ms, 3, "  simplify result: %s in %f sec\n", 
       resToName(node->res), nstat->time);
  
  decworkers();
  assert (node->res == BOOLECTOR_UNSAT || node->res == BOOLECTOR_SAT || node->res == 0);
  
  return NULL;
}

static void
simp ()
{
  int i;
    
  startphase("simplify");  
  
  //first sort nodes
  //sortnodes();
  
  startimer(&wct.simp);
  
  // simplify all split nodes
  for (i = 0; i < numnodes; i++)
  {
    Node *node = nodes[i];
    
    assert (node);
    assert (node->btor);
    assert (node->split == 0 || node->split == 1);
    
    if (!node->split) {
      continue;
    }
    node->split = 0;
        
    schedulejob(node, simpnode);
  }
  runjobs();
  joinjobs();
  
  stoptimer();
}


/*------------------------------------------------------------------------*/
/*
static void
lookaheadnode (Node *node) {
  assert (node);
  assert (node->btor);
  assert (!node->res);
  assert (node->state == LKHD);
  
  node->lookahead = boolector_lookahead(node->btor, lkhdvrb, lkhdtype, pr, 
                                        node->remset);
  if (node->lookahead) {
    msg (ms, 3, "  lookahead exp found: exp(%p) exp_id=%d\n", 
         node->lookahead, boolector_get_id(node->btor, node->lookahead));
  } else {
    msg (ms, 3, "  lookahead no exp found\n");
    if (ninc || nsatinc) {
      // do finish if sat solver is not incremental 
      // can not do multiple searches??
      assert(!nfin);
      node->finish = 1;
    } else {
      node->finish = !nfin;
    }
  }
}
*/

static void *
lookaheadnode (void * voidptr)
{
  Node *node = voidptr;
  
  assert (node);
  assert (node->btor);
  assert (!node->res);
  NStat *nstat;
  
   // lkhd statistic
#ifdef LKHDSPLITPAR
  lockstat();
#endif
  NEW(nstat, 1);
  nstat->round = rounds;
  nstat->id = node->id;
  nstat->depth = node->depth;
  nstat->time = currentime();
#ifdef LKHDSPLITPAR
  unlockstat();
#endif
    
  node->lookahead = boolector_lookahead(node->btor, lkhdvrb, lkhdtype, pr, 
                                        node->remset);
  // remset has only read access therefore is save to call in thread?  
  
  // lkhd statistic
#ifdef LKHDSPLITPAR 
  lockstat();
#endif
  nstat->time = currentime() - nstat->time;
  PUSH(lkhdstats, nstat); 
    
  if (node->lookahead) {
    msg (ms, 3, "  lookahead exp found: exp(%p) exp_id=%d\n", 
         node->lookahead, boolector_get_id(node->btor, node->lookahead));
  } else {
    msg (ms, 3, "  lookahead no exp found\n");
    if (ninc) {
      // do finish if sat solver is not incremental 
      assert(!nfin);
      node->finish = 1;
    } else {
      node->finish = !nfin;
    }
  }
  
#ifdef LKHDSPLITPAR 
  unlockstat();
  decworkers();
#endif
  
  return NULL;
}

int
firstlkhd () {
  int i;
  assert (numnodes > 0);
  if (numnodes < maxactive)
    i = numnodes - 1;
  else
    i = maxactive -1;
  return i;
}

int
donelkhd (int i) 
{
  int done = i >= 0 && numjobs < maxactive / 2;
  return done;  
}

static void 
lookahead () 
{  
  int i;
  size_t bytes, expected;
  
  sortnodes();
  
  startphase("lookahead"); 
  startimer(&wct.lkhd);
  
  bytes = countbytes();
    
  for ( i = firstlkhd(); donelkhd(i); i--)
  {
    Node *node = nodes[i];
    expected = boolector_bytes(node->btor);
    
    if (!node->searched) {
      nmsg (ms, 4, node,  " skip lookahead, node have not been searched yet\n");
      //printf ("*********** searched=false\n");
      continue;
    }
    // stop lookeahead if softmemlimit has exceeded
    if ((bytes + expected) > softlimbytes) {
      nmsg (ms, 2, node, " skip lookahead phase, "
          "softmemlimit %dMB expected mem %dMB\n", 
          bytes2mb(softlimbytes), bytes2mb(bytes + expected));
      continue;
    }
    
    //update number of bytes
    bytes += expected;

#ifdef LKHDSPLITPAR
    schedulejob(node, lookaheadnode);
#endif
#ifndef LKHDSPLITPAR
    lookaheadnode (node);
#endif
    
  }
#ifdef LKHDSPLITPAR   
  runjobs();
  joinjobs();
#endif
  
  stoptimer();
  //msg (ms, 1, "Done: %d lookahead jobs\n", numjobs_1);
   
}

static void splitbool(Node *orig) {
  int lkhdid;
  Node *clone;
  BoolectorNode *lkhdexp;
  Btor *btor;
  
  btor = orig->btor; 
  lkhdexp = orig->lookahead;
  assert (boolector_get_width(btor, lkhdexp) == 1);
  
  lkhdid = boolector_get_id(btor, lkhdexp);
  assert (lkhdid != 0);
  
  clone = newnode(orig);
  assert (clone);
  assert (clone->btor);
  clone->state = SPLIT;
  clone->lookahead = boolector_get_exp_by_id(clone->btor, lkhdid);
  assert (clone->lookahead);
  assert (lkhdid = boolector_get_id(clone->btor, clone->lookahead));
    
  //assert in orig
  msg (ms,4, "assert (%d %p) in orig\n", lkhdid, lkhdexp);
  //assert (!btor_find_in_ptr_hash_table(orig->remset, lkhdexp));
  boolector_assert(btor, lkhdexp);
  boolector_release(btor, lkhdexp);
  // do not release lookahead is still in remset table added
  //btor_insert_in_ptr_hash_table(orig->remset, lkhdexp);
      
  //assert inverted in clone
  btor = clone->btor;
  lkhdexp = clone->lookahead;
  
  msg (ms,4, "assert not(%d %p) in clone\n", lkhdid, lkhdexp);
  //assert (!btor_find_in_ptr_hash_table(clone->remset, lkhdexp));
  BoolectorNode *_not = boolector_not(btor, lkhdexp);
  boolector_assert (btor, _not);
  boolector_release (btor, _not);
  boolector_release (btor, lkhdexp);
  boolector_release (btor, lkhdexp); //release ref 2 for boolector_get_exp_by_id on clone
  // but do not release lookahead it is still in remset table added
  //btor_insert_in_ptr_hash_table(clone->remset, clone->lookahead);
      
  // reset orig
  orig->searched = 0;
  orig->lookahead = NULL;
  orig->state = READY;
  orig->split = 1;
  
  //reset clone
  clone->lookahead = NULL;
  clone->state = READY;
  clone->split = 1;
  
  nmsg (ms, 4, orig, "is original node\n");
  nmsg (ms, 4, clone, "is cloned node\n");
  msg (ms, 4, "  number of nodes: %d\n", numnodes);
}


static void splitcond(Node *orig) {
  assert (boolector_is_bcond_exp(orig->btor, orig->lookahead));
  BoolectorNode *p0 = boolector_get_param0 (orig->btor, orig->lookahead);
  // release lookahead
  boolector_release(orig->btor, orig->lookahead);
  // and set param0 as lookahead
  orig->lookahead = p0;
  splitbool(orig);
}

static void splitpeq0(Node *orig) {
  int lkhdid, len;
  Node *clone;
  BoolectorNode *lkhdexp;
  Btor *btor;
  btor = orig->btor; 
  lkhdexp = orig->lookahead;
  len = boolector_get_width(btor, lkhdexp);
  
  assert (boolector_is_mul_exp(btor, lkhdexp) || boolector_is_add_exp(btor, lkhdexp));
  assert (boolector_get_width(btor, lkhdexp) > 1);
    
  lkhdid = boolector_get_id(btor, lkhdexp);
  assert (lkhdid != 0);
  
  clone = newnode(orig);
  
  assert (clone);
  assert (clone->btor);
  clone->state = SPLIT;
  clone->lookahead = boolector_get_exp_by_id(clone->btor, lkhdid);
  assert (clone->lookahead);
  assert (lkhdid == boolector_get_id(clone->btor, clone->lookahead));
  
  //assert param = 0 in orig
  msg (ms,4, "assert (%d %p)=0 in orig\n", lkhdid, lkhdexp);
  BoolectorNode * _zero = boolector_zero (btor, len);
  BoolectorNode * _param = boolector_get_param0 (btor, lkhdexp);
  if (!boolector_is_var(btor, _param) || boolector_is_exp_assert_eq_ne_zero(btor, _param)) {
    boolector_release(btor, _param);
    _param = boolector_get_param1(btor, lkhdexp);
  }
  assert (boolector_is_var (btor, _param));
  assert (!boolector_is_exp_assert_eq_ne_zero(btor, _param));
  BoolectorNode * _eq = boolector_eq (btor, _param, _zero);
  boolector_assert (btor, _eq);
  boolector_release(btor, _zero);
  boolector_release(btor, _param);
  boolector_release(btor, _eq);
  boolector_release(btor, lkhdexp);
  
  //assert param != 0 in clone
  btor = clone->btor;
  lkhdexp = clone->lookahead;
    
  msg (ms,4, "assert (%d %p)!=0 in clone\n", lkhdid, lkhdexp);
  //assert (!btor_find_in_ptr_hash_table (clone->remset, lkhdexp));
  _zero = boolector_zero (btor, len);
  _param = boolector_get_param0 (btor, lkhdexp);
  if (!boolector_is_var(btor, _param) || boolector_is_exp_assert_eq_ne_zero(btor, _param)) {
    boolector_release(btor, _param);
    _param = boolector_get_param1(btor, lkhdexp);
  }
  assert (boolector_is_var (btor, _param));
  assert (!boolector_is_exp_assert_eq_ne_zero(btor, _param));
  BoolectorNode * _ne = boolector_ne (btor, _param, _zero);
  boolector_assert (btor, _ne);
  boolector_release(btor, _zero);
  boolector_release(btor, _param);
  boolector_release(btor, _ne);
  boolector_release (btor, lkhdexp); 
  boolector_release(btor, lkhdexp); //release ref 2 for boolector_get_exp_by_id on clone
  
  // reset orig
  orig->searched = 0;
  orig->lookahead = NULL;
  orig->state = READY;
  orig->split = 1;
  
  //reset clone
  clone->lookahead = NULL;
  clone->state = READY;
  clone->split = 1;
  
  nmsg (ms, 4, orig, "is original node\n");
  nmsg (ms, 4, clone, "is cloned node\n");
  msg (ms, 4, "  number of nodes: %d\n", numnodes);    
}

static void splitpeq1(Node *orig) {
  int lkhdid, len;
  Node *clone;
  BoolectorNode *lkhdexp;
  Btor *btor;
  btor = orig->btor; 
  lkhdexp = orig->lookahead;
  len = boolector_get_width(btor, lkhdexp);
  
  assert (boolector_is_mul_exp(btor, lkhdexp));
  assert (boolector_get_width(btor, lkhdexp) > 1);
    
  lkhdid = boolector_get_id(btor, lkhdexp);
  assert (lkhdid != 0);
  
  clone = newnode(orig);
  assert (clone);
  assert (clone->btor);
  clone->state = SPLIT;
  clone->lookahead = boolector_get_exp_by_id(clone->btor, lkhdid);
  assert (clone->lookahead);
  assert (lkhdid == boolector_get_id(clone->btor, clone->lookahead));
    
  //assert param0 = 0 in orig
  msg (ms,4, "assert (%d %p)=1 in orig\n", lkhdid, lkhdexp);
  //assert (!btor_find_in_ptr_hash_table (orig->remset, lkhdexp));
  BoolectorNode * _one = boolector_one (btor, len);
  BoolectorNode * _param = boolector_get_param0 (btor, lkhdexp);
  if (!boolector_is_var(btor, _param) || boolector_is_exp_assert_eq_ne_one(btor, _param)) {
    boolector_release(btor, _param);
    _param = boolector_get_param1(btor, lkhdexp);
  }
  assert (boolector_is_var (btor, _param));
  assert (!boolector_is_exp_assert_eq_ne_one(btor, _param));
  BoolectorNode * _eq = boolector_eq (btor, _param, _one);
  boolector_assert (btor, _eq);
  boolector_release(btor, _one);
  boolector_release(btor, _param);
  boolector_release(btor, _eq);
  boolector_release(btor, lkhdexp);
  
  //assert param0 != 0 in clone
  btor = clone->btor;
  lkhdexp = clone->lookahead;
  
  msg (ms,4, "assert (%d %p)!=1 in clone\n", lkhdid, lkhdexp);
  //assert (!btor_find_in_ptr_hash_table (clone->remset, lkhdexp));
  _one = boolector_one (btor, len);
  _param = boolector_get_param0 (btor, lkhdexp);
  if (!boolector_is_var(btor, _param) || boolector_is_exp_assert_eq_ne_one(btor, _param)) {
    boolector_release(btor, _param);
    _param = boolector_get_param1(btor, lkhdexp);
  }
  assert (boolector_is_var (btor, _param));
  assert (!boolector_is_exp_assert_eq_ne_one(btor, _param));
  BoolectorNode * _ne = boolector_ne (btor, _param, _one);
  boolector_assert (btor, _ne);
  boolector_release(btor, _one);
  boolector_release(btor, _param);
  boolector_release(btor, _ne);
  boolector_release(btor, lkhdexp);
  boolector_release (btor, lkhdexp); //release ref 2 for boolector_get_exp_by_id on clone
  
  // reset orig
  orig->searched = 0;
  orig->lookahead = NULL;
  orig->state = READY;
  orig->split = 1;
  
  //reset clone
  clone->lookahead = NULL;
  clone->state = READY;
  clone->split = 1;
  
  nmsg (ms, 4, orig, "is original node\n");
  nmsg (ms, 4, clone, "is cloned node\n");
  msg (ms, 4, "  number of nodes: %d\n", numnodes);    
}



static void splitbit(Node *orig, int param, int pos) {
  int lkhdid, len;
  Node *clone;
  BoolectorNode *lkhdexp;
  Btor *btor;
  
  assert (param == 0 || param == 1);
  
  btor = orig->btor; 
  lkhdexp = orig->lookahead;
  
  assert (boolector_is_mul_exp(btor, lkhdexp) 
  || boolector_is_add_exp(btor, lkhdexp));
  
  len = boolector_get_width (btor, lkhdexp);
  assert (len > 1);
  assert (pos >= 0 && pos < len);
  lkhdid = boolector_get_id(btor, lkhdexp);
  assert (lkhdid != 0);
  
  clone = newnode(orig);
  assert (clone);
  assert (clone->btor);
  clone->state = SPLIT;
  clone->lookahead = boolector_get_exp_by_id(clone->btor, lkhdid);
  assert (clone->lookahead);
  assert (lkhdid == boolector_get_id(clone->btor, clone->lookahead));
  
  //assert param0 = 0 in orig
  msg (ms,4, "assert (%d %p)[%d]=0 in orig\n", lkhdid, lkhdexp, pos);
  /*
  BoolectorNode * _p = (param == 0 ?
                    boolector_get_param0 (btor, lkhdexp) :
                    boolector_get_param1 (btor, lkhdexp));
                    */
  BoolectorNode * _slice = boolector_slice (btor, lkhdexp, pos, pos);
  boolector_assert (btor, _slice);  
  boolector_release(btor, _slice);
  //boolector_release(btor, _p);
  boolector_release(btor, lkhdexp);
  
  //assert param0 != 0 in clone
  btor = clone->btor;
  lkhdexp = clone->lookahead;
  
  
  msg (ms,4, "assert (%d %p)[%d]=1 in clone\n", lkhdid, lkhdexp, pos);
  /*_p = (param == 0 ?
        boolector_get_param0 (btor, lkhdexp) :
        boolector_get_param1 (btor, lkhdexp));*/
  _slice = boolector_slice(btor, lkhdexp, pos, pos);
  BoolectorNode * _nslice = boolector_not (btor, _slice);
  boolector_assert (btor, _nslice);
  //boolector_release(btor, _p);
  boolector_release(btor, _slice);
  boolector_release(btor, _nslice);
  boolector_release (btor, lkhdexp);
  boolector_release (btor, lkhdexp); //release ref 2 for boolector_get_exp_by_id on clone
  
  // reset orig
  orig->searched = 0;
  orig->lookahead = NULL;
  orig->state = READY;
  orig->split = 1;
  
  //reset clone
  clone->lookahead = NULL;
  clone->state = READY;
  clone->split = 1;
    
  nmsg (ms, 4, orig, "is original node\n");
  nmsg (ms, 4, clone, "is cloned node\n");
  msg (ms, 4, "  number of nodes: %d\n", numnodes);
}

static void *
splitnode (void * voidptr) {
  Node * orig = voidptr;
  assert (orig);
  assert (orig->btor);
  assert (orig->lookahead);
  assert (orig->searched >= 1);
  NStat *nstat;
  
#ifdef LKHDSPLITPAR
  lockstat ();                //lock everything exept clone
#endif
  NEW(nstat, 1);
  nstat->round = rounds;
  nstat->id = orig->id;
  nstat->depth = orig->depth;
  nstat->time = currentime();
  
  // TODO arrays??
  if (boolector_get_width(orig->btor, orig->lookahead) == 1 ) {
    splitbool(orig);
  } else if (boolector_is_bcond_exp(orig->btor, orig->lookahead)) {
    splitcond(orig);
  } else if (boolector_is_mul_exp(orig->btor, orig->lookahead) || 
             boolector_is_add_exp(orig->btor, orig->lookahead)) {
    BoolectorNode *param0 = boolector_get_param0(orig->btor, orig->lookahead);
    BoolectorNode *param1 = boolector_get_param1(orig->btor, orig->lookahead);
    //int len = boolector_get_width(orig->btor, orig->lookahead);    
        
    if ( ((boolector_is_var(orig->btor, param0) && 
        !boolector_is_exp_assert_eq_ne_zero(orig->btor, param0))
      || (boolector_is_var(orig->btor, param1) && 
        !boolector_is_exp_assert_eq_ne_zero(orig->btor, param1)))
       && (lkhdtype == 9 || lkhdtype == 12 || lkhdtype == 15)) {
      // split first = 0 if no var param is assert to zero
      boolector_release(orig->btor, param0);
      boolector_release(orig->btor, param1);      
      splitpeq0(orig);
    } else if ( ((boolector_is_var(orig->btor, param0) && 
        !boolector_is_exp_assert_eq_ne_one(orig->btor, param0))
      || (boolector_is_var(orig->btor, param1) && 
        !boolector_is_exp_assert_eq_ne_one(orig->btor, param1)))
       && (lkhdtype == 10 || lkhdtype == 15)) {
      // split then = 1 if no var param is assert to one
      boolector_release(orig->btor, param0);
      boolector_release(orig->btor, param1);
      splitpeq1(orig);
    } else if ((lkhdtype == 11 || lkhdtype == 13 || lkhdtype >=14)) {
      //TODO split bits here
      boolector_release(orig->btor, param0);
      boolector_release(orig->btor, param1);
            
      int id = boolector_get_id(orig->btor, orig->lookahead);
      int bit;
      
      BtorPtrHashBucket *b = btor_find_in_ptr_hash_table(orig->remset, &id);
      if (!b) {
        int *insert;
        NEW (insert, 1);
        *insert = id;
        b = btor_insert_in_ptr_hash_table(orig->remset, insert);
      }
      bit = b->data.asInt;
      
      splitbit(orig, 0, bit);
        
    } else {
      assert (0);
    }
  } else if (boolector_is_add_exp(orig->btor, orig->lookahead)) {
    splitpeq0(orig);
  } else {
    msg(ms, 0, "******************TODO split \n");
  }
  
  nstat->time = currentime() - nstat->time;
  PUSH(spstats, nstat);
#ifdef LKHDSPLITPAR
  unlockstat ();
  decworkers();
#endif
  return NULL;
}

static void 
split ()
{  
  int i;
  
  startphase ("split");
  startimer(&wct.split);
    
  // do all split jobs should not be more than maxactive/2
  int size = numnodes;         //numnodes is changing in for loop
  for (i = 0; i < size; i++)
  {
    Node *node = nodes[i];
    assert (node->state == READY);
    
    if (node->finish) {
      assert (!node->lookahead);
      nmsg (ms, 4, node, "  skip split, node is to finish (no further lkhd possible)\n");
      continue;
    }
    
    if (!node->lookahead) {
      nmsg (ms, 4, node, "  skip split, node has no lkhd for split\n");
      continue;
    }
    nmsg (ms, 2, node, "do split\n");
      
#ifdef LKHDSPLITPAR
    schedulejob (node, splitnode);
#endif
#ifndef LKHDSPLITPAR
    splitnode (node);
#endif    
  }
#ifdef LKHDSPLITPAR   
  runjobs();
  joinjobs();
#endif
  
  stoptimer ();
}

#if RUNMODE==DEBUG3
static void* 
searchnodetestthread (void *voidptr)
{  
  Node * n = voidptr;
          
  if (!n->finish) {  
    n->res = boolector_limited_sat (n->btor, -1, limit);
  } else {
    n->res = boolector_sat(n->btor);
  }
  n->searched++;
  return 0;
}
#endif

static void* 
searchnode (void *voidptr)
{
  NStat *nstat;  
  Node * node = voidptr;
  Btor * btor;
    
  assert (node);
  assert (node->btor);
  assert (!node->res);
  
  // search statistic
#if RUNMODE==PARALLEL || RUNMODE == DEBUG1
  lockstat();
#endif
  NEW(nstat, 1);
  nstat->round = rounds;
  nstat->id = node->id;
  nstat->depth = node->depth;
  int size = boolector_get_size(node->btor);
  int vars = boolector_get_vars(node->btor);
  nstat->sred = size;
  nstat->vred = vars;
  nstat->time = currentime();
  
#if RUNMODE==PARALLEL || RUNMODE == DEBUG1
  unlockstat();
#endif
  
  if (ninc) {
    // use a clone for search
    // run simplify on original!!!
    boolector_simplify(node->btor);
    btor = boolector_clone(node->btor);    
  } else {
    //search on orignal node
    btor = node->btor;
  }  
    
  boolector_reset_time(btor);
  if (!node->finish /*&& node->depth < 6*/) {
    //msg (ms, 3, "  search start sat: limit=%d\n", limit);
    node->res = boolector_limited_sat (btor, -1, limit);
    //btor_print_stats_btor(node->btor);
  } else {
    //msg (ms, 3, "  start sat:  no limit\n");
    // a try solve a fixed deth
    //printf ("---%d \n", node->depth);
    //node->finish = 1;
    node->res = boolector_sat(btor);
  }
  node->searched++;

  // search statistic
  
#if RUNMODE==PARALLEL || RUNMODE == DEBUG1
  lockstat();
#endif
  
  nstat->time = currentime() - nstat->time;
  nstat->sred = nstat->sred - boolector_get_size(btor);
  nstat->vred = nstat->vred - boolector_get_vars(btor);
  nstat->closed = node->res > 0;
  nstat->finished = node->finish;
  nstat->sat_time = boolector_get_sat_time(btor);
    
  finished += node->finish;
  fintotal += node->finish;
  PUSH(sestats, nstat); 
  

#if RUNMODE==PARALLEL || RUNMODE == DEBUG1
  unlockstat();
#endif
  
  if (ninc) {
    //delete clone res is stored
    boolector_delete(btor);
  }
  
  msg (ms, 3, "  reduction: from (%d-%d) to (%d-%d) = (%d-%d)\n", 
         size, vars, boolector_get_size(node->btor), 
         boolector_get_vars(node->btor), nstat->sred, nstat->vred);
  msg (ms, 3, "  search result: %s in %f sec sat %f sec\n", 
       resToName(node->res), nstat->time, nstat->sat_time);
  
#if RUNMODE==PARALLEL
  decworkers();
#endif
  return 0;
}

static void
search ()
{
  int i;
   
  startphase ("search");
  startimer (&(wct.search));
  
  //sort nodes again after split
  sortnodes();
  
#if RUNMODE==DEBUG3
  int numth = numnodes < maxactive || full() ? numnodes:maxactive;
  pthread_t ths [numth];
#elif RUNMODE==OMP
  int numth = numnodes < maxactive || full() ? numnodes:maxactive;
  omp_set_num_threads(numth);
  #pragma omp parallel for
#endif
  for (i = numnodes < maxactive || full() ? numnodes - 1: maxactive -1; i >=0; i--)
  {
    Node *node = nodes[i];  
    
    assert (node);
    assert (node->btor);
    assert (node->state == READY);
    
#if RUNMODE==PARALLEL    
    schedulejob(node, searchnode);
#elif RUNMODE==SEQUENTIAL
    searchnode(node);
#elif RUNMODE==DEBUG1 || RUNMODE==DEBUG2
    pthread_t th;
    pthread_create(&th, NULL, searchnode, node);
    pthread_join(th, NULL);
#elif RUNMODE==DEBUG3
    int fail = pthread_create(&(ths[i]), NULL, searchnodetestthread, node);
    assert (!fail);
#elif RUNMODE==OMP
    searchnodetestthread(node);
#endif
  }
#if RUNMODE==PARALLEL
  runjobs();
  joinjobs();
#elif RUNMODE==DEBUG3
  for (i =0; i < numth;i++) {
    int fail;
    fail = pthread_join(ths[i], NULL);
    assert (!fail);
  }
  
#endif
    
  stoptimer ();
}

static int 
flush () 
{
  int i, before = numnodes, flushed, res;
  Node * node;
  i = 0; 
  while (i < numnodes) 
  {
    node = nodes[i];
    assert (node);
    if (node->res == BOOLECTOR_UNSAT) {
      delnode (node);
    } else 
    {
      i++;
    }
  }
  if ((flushed = before - numnodes)) msg (ms, 1, "flush: deleted %d nodes\n", flushed);
  if (numnodes) 
  {
    res = 0; // UNKOWN
    msg (ms, 2, "flush: still have %d open nodes\n", numnodes);
  } else 
  {
    res = BOOLECTOR_UNSAT;
    msg (ms, 2, "flush: no more open nodes left\n");
  }
  return res;
}

static void updatelim () {
  
  //do not count finished nodes
  int delcor = deleted - finished;
  
  if (added == 0) {
    limit *= 2; // mem limit reached or no lkhd found
    if (!limit) limit = 1;
  }
  else if (delcor > added) {
    limit *= 2;
    if (!limit) limit = 1;
  }
  else if (delcor <= 0)  {
    limit /= 2;
  }
  else if (delcor < added) {
    limit = (9*limit)/10;
  }
  
  if (limit < lmin) limit = lmin;
  if (limit > lmax) limit = lmax;
  
  added = deleted = finished = 0;
}

/*------------------------------------------------------------------------*/

static int finish () {
  Node * node;
  int i, res;
  if ((res = flush ())) return res;
  for (i = 0; i < numnodes; i++) {
    node = nodes[i];
    assert (node);
    if (node->res == BOOLECTOR_SAT) break;
  }
  if (i < numnodes) {
    res = BOOLECTOR_SAT;
    node = nodes[i];
    assert (node);
  } else if (startpar) {
    //check if solved by parallel boolector instance
    lockdone();
    res = pinstance.res;
    unlockdone();
    if (res) {
      msg (ms, 0, "parallel solver instance won\n");
    } else {
      msg (ms, 1, "finish: no satisfiable node found but still %d nodes left\n", 
          numnodes);
    }
  } else {
    assert (res == 0);
    assert (numnodes > 0);
#ifndef NDEBUG
    for (i = 0; i < numnodes; i++) {
      node = nodes[i];
      assert (node);
      assert (!node->res);
      assert (node->btor);
    }
#endif
    msg (ms, 1, "finish: no satisfiable node found but still %d nodes left\n", 
         numnodes);
  }
  return res;
}

/*------------------------------------------------------------------------*/

static int catchedsig;

static void (*sig_int_handler)(int);
static void (*sig_segv_handler)(int);
static void (*sig_abrt_handler)(int);
static void (*sig_term_handler)(int);

static void resetsighandlers () {
  (void) signal (SIGINT, sig_int_handler);
  (void) signal (SIGSEGV, sig_segv_handler);
  (void) signal (SIGABRT, sig_abrt_handler);
  (void) signal (SIGTERM, sig_term_handler);
}

static void caughtsigmsg (int sig) {
  msg (ms , 0, "CAUGHT SIGNAL %d\n", sig);
  fflush (stdout);
}

static void catchsig (int sig) {
  if (!catchedsig) {
    fflush (stdout);
    catchedsig = 1;
    caughtsigmsg (sig);
    stats ();
    msg (ms, 0, "s %s\n", resToName(0));
    caughtsigmsg (sig);
  }
  resetsighandlers ();
  raise (sig);
}

static void setsighandlers () {
  sig_int_handler = signal (SIGINT, catchsig);
  sig_segv_handler = signal (SIGSEGV, catchsig);
  sig_abrt_handler = signal (SIGABRT, catchsig);
  sig_term_handler = signal (SIGTERM, catchsig);
}

static void usage() {
  int64_t tmem = getotalmem();
  int64_t memmb = (( tmem + (1 << 20) - 1 ) >> 20);
  int c = getcores();
  
  printf (
"usage: pboolector [<option>...][<input>]\n"
"\n"
"where <option> is one of the following:\n"
"\n"
"  -h|--help             print usage information and exit\n"
"  -v|--verbose <level>  set verbosity level\n"
"                        (default 0, min -1 (quiet), max 4)\n"
"  -lv <level>           set lkhd verbosity level (default 0, min 0, max 4)\n"
"  -bv <level>           set boolector verbosity level\n"
"  -l|--limit <lim>      set search limit \n"
"                        (default 5000, min -1 (no limit) max 1000000)\n"
"  -lmin <lim>           minimal limit (def 1000, min 0, max INT_MAX)\n"
"  -lmax <lim>           maximal limit (def 50000, min 0, max INT_MAX)\n"
"  -r|--rounds <num>     limit number of rounds -1... no limit \n"
"                        (default -1, min -1, max= INT_MAX)\n"
"  -lt <type>            lkhd type (default 14, min 0, max 17)\n"
"                        0..BEQ1VN 1..BEQ1V1 2..BEQ1OTHER\n"
"                        3..ULT1N 4..BCONDN 5..VAR1\n"
"                        6..SLICE1 7..AND1 8..OTHER1\n"
"                        9..MULNV0 10..MULNV1 11..MULNBIT0\n"
"                        12..ADDNV0 13..ADDNBIT0\n"
"                        14..CFO combine with fixed order\n"
"                        15..CFOS combine with fixed order and MUL/ADD types\n"
"                        16..CRA combine with random selection\n"
"                        17..CPR combine by probing\n"
"  -il                   initial lookahead for printing distribution\n"
"  -pr                   probe specified lookahead type and return max exp\n"
"  -flr                  do a intial failed literal reduction with probing\n"
"  -m <mb>               system memory limit in mega bytes\n"
"                        (system default %ld MB)\n"
"  -t <workers>          max number of worker treads (system default %d)\n"
"  -a <nodes>            max active nodes (default %d)\n"
"  -sp                   start parallel boolector instance\n"
"  -ni                   use boolector and sat solver non incremental\n"
"                        (clones instance before each search)\n"
"  -nf                   not finish nodes if no lookahead is found\n"
"                        (only in incremental mode available)\n",
          memmb, c, WORKERSTOMAXACTIVE(c)
  );
}

#include <stdio.h>

int
main (int argc, char ** argv)
{
  int i, res;
  FILE * input_file;
  const char * input_name = 0;
  int parsesmt2 = 0;
  const char * parse_error;
  Node *root;
  BtorParser * parser;
  BtorParseOpt parse_opt;
  BtorParseResult parse_res;
  
      
  // init
  verbosity = -2; lkhdvrb = -1; btorvrb = -1;
  lkhdtype = -1;
  limit = -2; lmin = -1, lmax = -1;
  maxrounds = -2;
  lkhdtype = -1;
  ms = newmsg("pboolector");
  pthread_mutex_init(&lock.done.mutex, 0);
  pthread_mutex_init(&lock.mem.mutex, 0);
  pthread_mutex_init(&lock.stat.mutex, 0);
  pthread_mutex_init(&lock.workers.mutex, 0);
  
  pthread_cond_init(&workerscond, 0);

#if RUNMODE==OMP
  omp_set_num_threads(4);
#endif
 
  // option parsing
  for (i = 1; i < argc; i++) 
  {
    if (!strcmp (argv[i], "-h") || !strcmp (argv[i], "--help"))
    {
      usage();
      delmsg(ms);
      exit (0);
    } 
    else if (!strcmp (argv[i], "-v"))
    {
      if (verbosity >= 0) err(ms, "multiple '-v' options");
      if (++i == argc) err (ms, "argument to '-v' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-v' option");
      verbosity = atoi (argv[i]);
      if (verbosity < -1 || verbosity > 4)
        err (ms, "expected number between -1 and 4 in '-v' %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-lv")) {
      if (lkhdvrb >= 0) err(ms, "multiple -lv options");
      if (++i == argc) err (ms, "argument to '-lv' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-lv' option");
      lkhdvrb = atoi (argv[i]);
      if (lkhdvrb < 0 || lkhdvrb > 4)
        err (ms, "expected number between 0 and 4 in '-lv %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-bv")) {
      if (btorvrb >= 0) err(ms, "multiple -bv options");
      if (++i == argc) err (ms, "argument to '-bv' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-bv' option");
      btorvrb = atoi (argv[i]);
      if (btorvrb < 0 || btorvrb > 4)
        err (ms, "expected number between 0 and 4 in '-bv %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-lt")) {
      if (lkhdtype >= 0) err(ms, "multiple -lt options");
      if (++i == argc) err (ms, "argument to '-lt' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-lt' option");
      lkhdtype = atoi (argv[i]);
      if (lkhdtype < 0 || lkhdtype > 17)
        err (ms, "expected number between 0 and 17 in '-lt %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-il")) {
      if (initiallkhd) err(ms, "multiple -il options");
      initiallkhd = 1;
    } 
    else if (!strcmp (argv[i], "-pr")) {
      if (pr) err(ms, "multiple -pr options");
      pr = 1;
    } 
    else if (!strcmp (argv[i], "-flr")) {
      if (flr) err(ms, "multiple -flr options");
      flr = 1;
    } 
    else if (!strcmp (argv[i], "-l"))
    {
      if (limit > -2) err(ms, "multiple '-l' options");
      if (++i == argc) err (ms, "argument to '-l' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-l' option");
      limit = atoi (argv[i]);
      if (limit < -1 || limit > 1000000)
        err (ms, "expected number between -1 and 1000000 in '-l %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-lmin")) {
      if (lmin > -1) err(ms, "multiple '-lmin' options");
      if (++i == argc) err (ms, "argument to '-lmin' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-lmin' option");
      lmin = atoi (argv[i]);
      if (lmin < 0)
        err (ms, "expected number between 0 and INT_MAX in '-lmin %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-lmax")) {
      if (lmax > -1) err(ms, "multiple '-lmax' options");
      if (++i == argc) err (ms, "argument to '-lmax' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-lmax' option");
      lmax = atoi (argv[i]);
      if (lmax < 0)
        err (ms, "expected number between 0 and INT_MAX in '-lmax %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-r") || !strcmp (argv[i], "--rounds"))
    {
      if (maxrounds >= -1) err(ms, "multiple '-r' options");
      if (++i == argc) err (ms, "argument to '-r' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-r' option");
      maxrounds = atoi (argv[i]);
      if (maxrounds < -1)
        err (ms, "expected number between -1 and INT_MAX in '-r %s'",
             argv[i]);
    } 
    else if (!strcmp (argv[i], "-m"))
    {
      if (hardlimbytes) err(ms, "multiple '-m' options");
      if (++i == argc) err (ms, "argument to '-m' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-m' option");
      hardlimbytes = atoi (argv[i]);
      if (hardlimbytes > 0) hardlimbytes <<= 20;
      else {
        hardlimbytes = INT_MAX;
        //err (ms, "expected number greater 1 for option '-m'");
      }
    }
    else if (!strcmp (argv[i], "-t"))
    {
      if (maxnumworkers) err(ms, "multiple -t options");
      if (++i == argc) err (ms, "argument to '-t' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-t' option");
      maxnumworkers = atoi (argv[i]);
      if (maxnumworkers <= 0) {
        err (ms, "expected number greater 0 for option '-t'");
      }
    }
    else if (!strcmp (argv[i], "-a"))
    {
      if (maxactive) err(ms, "multiple -a options");
      if (++i == argc) err (ms, "argument to '-a' missing");
      if (!isnum (argv[i]))
        err (ms, "expected number as argument to '-a' option");
      maxactive = atoi (argv[i]);
      if (maxactive <= 1) {
        err (ms, "expected number greater 1 for option '-a'");
      }
    }
    else if (!strcmp (argv[i], "-sp"))
    {
      if (startpar) err(ms, "multiple -sp options");
      startpar = 1;
    }
    else if (!strcmp (argv[i], "-ni"))
    {
      if (ninc) err(ms, "multiple -ni options");
      if (ninc | nfin) err(ms, "-ni not possible when -nsi or -nf is option is set");
      ninc = 1;
    } 
    else if (!strcmp (argv[i], "-nf"))
    {
      if (nfin) err(ms, "multiple -nf options");
      if (ninc) err(ms, "-nf not possible when -ni option is set");
      nfin = 1;
    } 
    else if (argv[i][0] == '-')
      err (ms, "invalid command line option '%s' (try '-h')", argv[i]);
    else if (input_name)
      err (ms, "two input files '%s' and '%s' specified (try '-h')", input_name, argv[i]);
    else input_name = argv[i];
  }
  
  if(input_name) {
    input_file = fopen (input_name, "r");
    if (!input_file) err (ms, "can not read '%s'", input_name);
    //TODO just check file ending
    if (strstr(input_name, ".smt2"))
      parsesmt2 = 1;
  } else input_name = "<stdin>", input_file = stdin;
    
  setsighandlers ();
  setenv("LGLPLAIN", "0", 1); 
  
  //set default values
  verbosity = verbosity < -1 ? 0 : verbosity;
  lkhdvrb = lkhdvrb < 0 ? 0 : lkhdvrb;
  btorvrb = btorvrb < 0 ? 0 : btorvrb;
  
  setvrb(ms, verbosity);
  
  lkhdtype = lkhdtype < 0 ? 14 : lkhdtype;
  
  limit = limit < -1 ? 5000 : limit;
  lmin = lmin < 0 ? LMIN : lmin;
  lmax = lmax < 0 ? LMAX : lmax;
  if (limit != -1 && (lmin > lmax || limit < lmin || limit > lmax)) {
    err (ms, "limit have to be lmin (%d) <= limit(%d) <= lmax (%d)", 
         lmin, limit, lmax);
  }
  
  maxrounds = maxrounds < -1 ? -1 : maxrounds;
  if (!hardlimbytes)
    hardlimbytes = getotalmem();
  // add nodes until memory of 33% of hardlimit usage
  softlimbytes = (hardlimbytes) / 3.0 ;
  if (!maxnumworkers) maxnumworkers = getcores();
  if (startpar && maxnumworkers > 1) {
    msg(ms, 0, "using one worker for parallel boolector instance\n");
    maxnumworkers--;
  }
  if (!maxactive) maxactive = WORKERSTOMAXACTIVE(maxnumworkers);
  
  if (maxactive < maxnumworkers) {
    err (ms, "maxactive(%d) have to be <= max number of worker threads(%d)",
         maxactive, maxnumworkers);
  }
      
  mm = btor_new_mem_mgr();
  
  
  msg (ms, 0, "pbooolector v 0.0\n");
  msg (ms, 0, "set LGLPLAIN=%s\n", getenv("LGLPLAIN"));
  msg (ms, 0, "set BTORAPITRACE=%s\n", getenv("BTORAPITRACE"));
  msg (ms, 0, "options:\n");
  msg (ms, 0, "verbose=%d\n", verbosity);
  msg (ms, 0, "limit=%d\n", limit);
  msg (ms, 0, "lmin=%d\n", lmin);
  msg (ms, 0, "lmax=%d\n", lmax);
  msg (ms, 0, "parser=%s\n", parsesmt2 ? "smt2" : "btor"); 
  msg (ms, 0, "hard memory limit of %uMB\n", bytes2mb(hardlimbytes));
  msg (ms, 0, "soft memory limit of %luMB\n", bytes2mb(softlimbytes));
  msg (ms, 0, "maxworkers: %d\n", maxnumworkers + startpar);
  msg (ms, 0, "maxactive: %d\n", maxactive);
  msg (ms, 0, "startparallel: %d\n", startpar);
  msg (ms, 0, "lookahead type: %d\n", lkhdtype);
  msg (ms, 0, "initial failed literal reduction: %d\n", flr);
  
  root = newnode (NULL);
  assert (root);
  assert (root->btor);
  assert (nodes[0] == root);
  
  // file parsing
  msg (ms, 0, "parse input file %s\n", input_name);
  BTOR_CLR (&parse_opt);
  if (parsesmt2)
    parser = btor_smt2_parser_api ()->init (root->btor, &parse_opt);
  else
    parser = btor_btor_parser_api ()->init (root->btor, &parse_opt);
  msg (ms, 2, "parse options: inc=%d, verb=%d, model=%d, win=%d \n", 
       parse_opt.incremental,
       parse_opt.verbosity, 
       parse_opt.need_model, 
       parse_opt.window);

  if (parsesmt2)
    parse_error = btor_smt2_parser_api()->parse (parser, 0, input_file, 
                                                 input_name, &parse_res);
  else
    parse_error = btor_btor_parser_api()->parse (parser, 0, input_file, 
                                                 input_name, &parse_res);
    
    
  if (parse_error)
    err (ms, parse_error);
  
  msg (ms, 2, "parse result: logic=%d, stat=%d, res=%d, inputs=%d outputs=%d \n", 
          parse_res.logic,
          parse_res.status,
          parse_res.result,
          parse_res.ninputs,
          parse_res.noutputs);
  // assert outputs
  for ( i = 0; i < parse_res.noutputs; i++) {
    //printf ("%p \n", parse_res.outputs[i]);    
    boolector_assert(root->btor, parse_res.outputs[i]);
  }
  
  if (parsesmt2)
    btor_smt2_parser_api()->reset (parser); 
  else 
    btor_btor_parser_api()->reset (parser); 
  fclose(input_file);
        
  if (startpar) {
    startparallel();
  }
  
  setincusage(nodes[0]->btor);
  
  int size =  boolector_get_size(root->btor);
  int vars = boolector_get_vars(root->btor);
  int fl = 0; //failed literals
  
  msg(ms, 0, "problem size: nodes: %d vars: %d\n", size, vars);
  
  //initial failed literal reduction
  if (flr) {
    startimer(&wct.flr);
    // make first simplification
    msg (ms, 0, "initial failed literal reduction...\n");
    root->res = boolector_failed_literal_reduction(root->btor, lkhdvrb, &fl);
    stoptimer();
  } else {
    msg (ms, 0, "intial  failed literal reduction is turned off\n");
  }
    
  msg(ms, 0, "failed literal reduction: nodes: %0.2f %% vars: %0.2f %%\n",
      100.0 - (boolector_get_size(root->btor)*100.0/size),
      100.0 - (boolector_get_vars(root->btor)*100.0/vars));
  msg(ms, 0, "failed literals: %d\n", fl);
  msg(ms, 0, "failed literal result: %d\n", root->res);
  
  // cube and conquer
  msg (ms, 0, "start cube and conquer\n");
  report();
  
  //initial lookahead for printing distr
  if (initiallkhd)
  {
    //simpnode(nodes[0]);
    simp();
    BoolectorNode *lkhd = boolector_lookahead(nodes[0]->btor, lkhdvrb, 
                                              lkhdtype, pr, nodes[0]->remset);
    if (lkhd) boolector_release(nodes[0]->btor, lkhd);
  }
  
  if (!(res = finish()) && maxrounds < 0 ? 1 : rounds < maxrounds)
  {
    initial();
        
    search();
    
    res = finish();
    added = deleted = finished = 0;
    while (!res && maxrounds < 0 ? 1 : rounds < maxrounds)
    {      
      incrounds ();
      
      //simp does not need to be done is called implizit by sat call
      //simp();      
      //if (res = finish ()) break;
      
      lookahead ();
            
      split ();
            
      report ();
      
      updatelim ();
      
      search ();
      
      res = finish ();
    }
  }
  report();
  
  if (startpar) {
    joinparallel(res);
  }
  
  final();
  
  stats ();
  
  assert (maxrounds < 0 || rounds < maxrounds ? 
            res == BOOLECTOR_UNSAT || res == BOOLECTOR_SAT : 1);
  msg (ms, 0, "s %s\n", resToName(res));
  
  msg (ms, 0, "cleaning up after %d rounds\n", rounds);  
  while (numnodes)
    delnode (nodes[0]);
  
  DEL (nodes, sizenodes);
  DEL (jobs, sizejobs);
  for (i = 0; i < numsistats; i++) 
    DEL (sistats[i], 1);
  DEL(sistats, sizesistats);
  for (i = 0; i < numlkhdstats; i++) 
    DEL (lkhdstats[i], 1);
  DEL(lkhdstats, sizelkhdstats);
  for (i = 0; i < numspstats; i++) 
    DEL (spstats[i], 1);
  DEL(spstats, sizespstats);
  for (i = 0; i < numsestats; i++) 
    DEL (sestats[i], 1);
  DEL(sestats, sizesestats);
  
  btor_delete_mem_mgr (mm);
  
  assert (currentbytes == 0);
  
  delmsg(ms);
 
  return res;
}


