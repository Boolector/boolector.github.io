/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */
#include "btorlkhd.h"
#include "btorcore.h"
#include "btoriter.h"
#include "btorpbtor.h"
#include "pboolector.h"

#include <assert.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>

#include "btorclone.h"

//onfly = 1 probably not work anymore this was the first implementation of lookahead
int onfly = 0;

// messages
/*------------------------------------------------------------------------*/
typedef struct Msg {
  char* prefix;
  int verbosity;
  double startime;
} Msg;

/*------------------------------------------------------------------------*/

static double 
currentime () {
  double res = 0;
  struct timeval tv;
  if (!gettimeofday (&tv, 0))
    res = 1e-6 * tv.tv_usec, res += tv.tv_sec;
  return res;
}

static double 
getime (Msg *msg) { return currentime () - msg->startime; }

static Msg * 
newmsg(Btor *btor, char *prefix) 
{
  Msg * msg;
  BTOR_NEW(btor->mm, msg);
  msg->prefix = prefix;
  msg->verbosity = 0;
  msg->startime = currentime();
  return msg;
}

static void
delmsg(Btor *btor, Msg* msg)
{
  BTOR_DELETE(btor->mm, msg);
}

static int 
vrb (Msg *msg) 
{
  return msg->verbosity;
}

static void
setvrb(Msg* msg, int v)
{
  assert (v >= -1 && v <= 4);
  msg->verbosity = v;
}

static void
msg (Msg *msg, int level, char *fmt, ...)
{
  assert (msg);
  if (level <= msg->verbosity) {
    assert (fmt);
    double t = getime(msg);
    va_list list;
    va_start (list, fmt);
    fprintf (stdout, "[%s] %d - %.4f ", msg->prefix, level, t);
    if (level == 4) fprintf (stdout, "*** ");
    vfprintf (stdout, fmt, list);
    va_end (list);
    fflush(stdout);
  }
}

// message without prefix
static void
msgwop (Msg *msg, int level, char *fmt, ...)
{
  assert (msg);
  if (level <= msg->verbosity) {
    assert (fmt);
    va_list list;
    va_start (list, fmt);
    vfprintf (stdout, fmt, list);
    va_end (list);
    fflush(stdout);
  }
}

typedef enum LkhdT
{
  LKHD_BEQ1VN = 0,
  LKHD_BEQ1V1 = 1,
  LKHD_BEQ1OTHER = 2,        // other BV eqalities which are not BEQ1PV or BEQ1V
  LKHD_ULTN1 = 3,
  LKHD_BCOND = 4,
  LKHD_VAR1 = 5,
  LKHD_SLICE1 = 6,
  LKHD_AND1 = 7,
  LKHD_OTHER1 = 8,        // everything else which is one bit 
  LKHD_MULN0 = 9,
  LKHD_MULN1 = 10,
  LKHD_MULNBIT = 11,
  LKHD_ADDN0 = 12,
  LKHD_ADDNBIT = 13,
  // combined lookaheads
  LKHD_ALL = 14,        // TODO better combinations
  LKHD_ALL1 = 15,
  LKHD_ALL2 = 16,
  LKHD_ALL3 = 17
    
} LkhdT;

//LkhdKind lkhdtype = LKHD_ALL;

int printhead = 20;

static const char* const LkhdKindToName[] =
{
  "BEQ1VN",
  "BEQ1V1",
  "BEQ1OTHER",
  "ULTN1",
  "BCOND",
  "VAR1",
  "SLICE1",
  "AND1", 
  "OTHER1",
  "MULN0",
  "MULN1",
  "MULNBIT",
  "ADDN",
  "ADDNBIT",
  "ALL",
  "ALL1",
  "ALL2",
  "ALL3"
};

static char* BtorKindToName[] = 
{  
  "INVALID",
  "BV_CONS",
  "BV_VAR",
  "PARAM",      /* parameter for lambda expressions */ //--------
  "SLICE",
  "AND",
  "BEQ",             /* equality on bit vectors */
  "FEQ",             /* equality on arrays */
  "ADD",        //--------
  "MUL",
  "ULT",
  "SLL",
  "SRL",
  "UDIV",        //--------
  "UREM",
  "CONCAT",
  "APPLY",
  "LAMBDA",         /* lambda expression */ //--------
  "BCOND",          /* conditional on bit vectors */
  "ARGS" ,
  "UF",
  "PROXY",          /* simplified expression without children */ //-----
  "NUM_OPS"
};
  
/*------------------------------------------------------------------------*/

typedef struct LkhdScore {
  int hsc;                // heuristic score
  double psr;                // positive size reduction on real lkhd
  double nsr;                // negative size reduction on real lkhd
  double pvr;                // positive size reduction on real lkhd
  double nvr;                // negative size reduction on real lkhd
  int pres;                // positive result on real lkhd
  int nres;                // negative result on real lkhd
  double scr;                //  score
} LkhdScore;

typedef struct AddExpInfo {
  int pos;                // positive occurences
  int neg;                // negative occurences
  int indsn;                // independen sub nodes
  int indsnl;                // independent sub nodes of left parameter
  int indsnr;                //independent sub nodes of right parameter
  BtorNode *exp;        // corresponding expresion
  LkhdScore sc;                // score for each lookahead heuristic
} AddExpInfo;

typedef struct LkhdStats {
  int cnt, psum, nsum;
  long long int maxsc, minsc;
  BtorNode* maxexp;
} LkhdStats;

/*------------------------------------------------------------------------*/

//forward decls
static void 
find_constr_children (Btor *btor, BtorPtrHashTable *constr_children, Msg *ms);
static void
add_constr_children_to_table (Btor *btor, BtorNode *constr, 
                              BtorPtrHashTable *constr_children);
static void 
fill_add_exp_infos (Btor* btor, BtorPtrHashTable *constr_children,
                    BtorPtrHashTable* add_exp_infos);
static BtorNode *
lkhd_find (Btor* btor, BtorPtrHashTable* add_exp_infos, 
           BtorPtrHashTable * remset, int pr, Msg *ms, LkhdT lkhdtype);
static void 
delete_add_exp_infos (BtorPtrHashTable* add_exp_infos);

// old 
static BtorNode *
count_on_the_fly (Btor *btor, BtorPtrHashTable *constr_children, Msg *ms);

// debug
static void 
msg_exp(int level, AddExpInfo* add_info, Msg *ms, LkhdT lkhdtype);
static void 
msg_exp_head (int level, AddExpInfo *exp_info, int pr, Msg *ms);

/*------------------------------------------------------------------------*/
// TODO utils make implement it  btorexp.c
static int 
varcount(Btor * btor) 
{
  return btor->bv_vars->count /*+ btor->array_vars->count*/;
}

static int 
sizeut(Btor * btor) 
{
  return btor->nodes_unique_table.num_elements;
}

/*------------------------------------------------------------------------*/


BtorNode * 
btor_lkhd (Btor * btor, int v, int type, int pr, 
            BtorPtrHashTable * remset)
{
  BtorPtrHashTable *constr_children;
  BtorPtrHashTable *add_exp_infos;
    
  LkhdT lkhdtype = type;
  
  Msg *ms = newmsg (btor, "lkhd");
  setvrb(ms, v);
      
  msg (ms, 1, "start lookahead\n");
  
  assert(btor);
    
  constr_children = btor_new_ptr_hash_table(btor->mm,
                                                (BtorHashPtr) btor_hash_exp_by_id,
                                                (BtorCmpPtr) btor_compare_exp_by_id);
  add_exp_infos = btor_new_ptr_hash_table(btor->mm,
                                      (BtorHashPtr) btor_hash_exp_by_id,
                                      (BtorCmpPtr) btor_compare_exp_by_id);
  find_constr_children(btor, constr_children, ms);
    
  msg (ms , 2, "search for lookahead candidates in unique table of size=%d, vars=%d\n", 
       sizeut (btor), varcount (btor));
  
  BtorNode *lkhd;
  if (onfly) 
  {
    lkhd = count_on_the_fly(btor, constr_children, ms);
  } else 
  {    
    fill_add_exp_infos(btor, constr_children, add_exp_infos); 
    lkhd = lkhd_find (btor, add_exp_infos, remset, pr, ms, lkhdtype);
  }
  
  
  if (lkhd)
  {
    BtorNode *real_lkhd = BTOR_REAL_ADDR_NODE(lkhd);
    BtorPtrHashBucket *bucket = btor_find_in_ptr_hash_table (add_exp_infos, real_lkhd);
    assert (bucket);
    AddExpInfo *info = (AddExpInfo *) bucket->data.asPtr;
    msg (ms, 1, "lookahead found return;\n");
    msg_exp_head(1, info, pr, ms);
    msg_exp(1,info, ms, lkhdtype);
    msg(ms, 1, "pointer %p\n", lkhd);
  }
  else
  {
    msg (ms , 1, "no lookahead expression found \n");
  }
  
  btor_delete_ptr_hash_table(constr_children);
  delete_add_exp_infos(add_exp_infos);
  btor_delete_ptr_hash_table(add_exp_infos);
  
  delmsg (btor, ms);  
  
  return lkhd;
}

BtorNode * 
btor_lkhd_dummy (Btor * btor, int v, int type, int pr, 
            BtorPtrHashTable * remset)
{
  (void)v; (void)type; (void)pr; (void) remset;
  int i;
  for (i = 0; i < btor->nodes_unique_table.size; i++) {
    BtorNode *cur =  btor->nodes_unique_table.chains[i];
    // follow collision chain
    while (cur) {
      assert (BTOR_IS_REGULAR_NODE(cur));
      
      if (!cur->constraint && cur->len== 1 && cur->kind != BTOR_BV_CONST_NODE) {
        return cur;
      }
      cur = cur->next;
    }    
  }
  return 0;  
}

BtorNode * 
btor_lkhd_simple (Btor * btor)
{
  int i;
  for (i = 0; i < btor->nodes_unique_table.size; i++) {
    BtorNode *cur =  btor->nodes_unique_table.chains[i];
    // follow collision chain
    while (cur) {
      assert (BTOR_IS_REGULAR_NODE(cur));
      
      if (cur->id == 2825) {
          int dbg = 0;
          dbg++;
      }
      
      if (!cur->constraint && cur->len== 1 && cur->kind != BTOR_BV_CONST_NODE) {
        return cur;
      }
      cur = cur->next;
    }    
  }
  return 0;  
}

/*------------------------------------------------------------------------*/

// iterate through constraint tables and add children to constr_children table  
static void 
find_constr_children (Btor *btor, BtorPtrHashTable *constr_children, Msg *ms) 
{
  BtorNode *exp;
  BtorPtrHashBucket * bucket;
  
  assert(constr_children);
  
  msg (ms , 2, "build up constraint children table \n");
  msg (ms , 2, "varsubst %d, embedded %d, unsynthesized %d, syntehsized %d \n",
       btor->varsubst_constraints->count,
       btor->embedded_constraints->count,
       btor->unsynthesized_constraints->count,
       btor->synthesized_constraints->count );
  
  bucket = btor->embedded_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);
    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
    // we just have boolsch embedded constraints
    assert (exp->len == 1);
    
    add_constr_children_to_table(btor, exp, constr_children);
    bucket = bucket->next;
  }
  
  bucket = btor->unsynthesized_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);
    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
    
    add_constr_children_to_table(btor, exp, constr_children);
    bucket = bucket->next;
  }
  bucket = btor->synthesized_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);
    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
       
    add_constr_children_to_table(btor, exp, constr_children);
    bucket = bucket->next;
  }
  msg (ms , 1, "found %d constraint children for candidates\n", constr_children->count); 
}

/**
 * add children of constraints to constr_children table (depth first search)
 */
static void
add_constr_children_to_table (Btor *btor, BtorNode *constr, 
                      BtorPtrHashTable *constr_children) 
{
  int i;
  BtorNodePtrStack stack;
  BtorNode *cur;
  
  assert(btor);
  assert(constr);
  assert(constr_children);
  
  // constraint have to be regular
  cur = BTOR_REAL_ADDR_NODE(constr);
  assert(cur->constraint);  
  
  BTOR_INIT_STACK (stack);
  BTOR_PUSH_STACK(btor->mm, stack, constr);
    
  while (!BTOR_EMPTY_STACK(stack))
  {
    cur = BTOR_REAL_ADDR_NODE (BTOR_POP_STACK (stack));
        
    //add cur to hashtable
    if (!btor_find_in_ptr_hash_table(constr_children, cur))
    {
      //printf ("child of synthesized %d %d\n", cur->id, cur->constraint);
      btor_insert_in_ptr_hash_table(constr_children, cur);
      //add children to stack    
      for (i = cur->arity - 1; i >= 0; i--) 
      {
        BTOR_PUSH_STACK (btor->mm, stack, cur->e[i]);
      }
    }
  }
  BTOR_RELEASE_STACK (btor->mm, stack);
}

/*------------------------------------------------------------------------*/

/**
 * count number independent subnodes of exp
 * return number of independent subnodes + 1 (exp is counted too)
 */
int
count_indep_subnodes (Btor* btor, BtorNode* exp)
{  
  BtorNodePtrStack stack;
  BtorNode *cur;
  int i, cnt = 0;
  
  assert (btor);
  assert (exp);
  
  BTOR_INIT_STACK (stack);
  BTOR_PUSH_STACK(btor->mm, stack, exp);
  
  while (!BTOR_EMPTY_STACK (stack)) 
  {    
    cnt++;
    cur = BTOR_POP_STACK (stack);
    
    assert (BTOR_IS_REGULAR_NODE(cur));
    
    //add children to stack which have 1 parent
    for (i = cur->arity - 1; i >= 0; i--) 
    {
      BtorNode *child = BTOR_REAL_ADDR_NODE (cur->e[i]);
      assert (child);
      assert (child->parents > 0);
      if (child->parents == 1)
      {
        BTOR_PUSH_STACK (btor->mm, stack, child);
      }
    }
  }  
  BTOR_RELEASE_STACK (btor->mm, stack);
  return cnt;
}

static void 
fill_add_exp_infos (Btor *btor, BtorPtrHashTable *constr_children, 
                    BtorPtrHashTable *exp_infos)
{
  int i, j;
  for (i = 0; i < btor->nodes_unique_table.size; i++) {
    BtorNode *cur =  btor->nodes_unique_table.chains[i];
    // follow collision chain
    while (cur) {
      assert (BTOR_IS_REGULAR_NODE(cur));
      assert (cur->kind != BTOR_INVALID_NODE);
      
      // just fill up add_exp_infos with constraint children
      if (btor_find_in_ptr_hash_table(constr_children, cur)) {
        for (j = 0; j < cur->arity; j++)
        {
          AddExpInfo *exp_info;
        
          BtorNode *exp = cur->e[j];
          BtorNode *real_exp = BTOR_REAL_ADDR_NODE (exp);
        
          BtorPtrHashBucket *bucket = 
                      btor_find_in_ptr_hash_table (exp_infos, real_exp);
          // put node to exp_infos if node is not in there
          if (!bucket) {
            //create exp info
            BTOR_NEW (exp_infos->mem, exp_info);
            BTOR_CLR (exp_info);
            exp_info->exp = real_exp;
            
            // add to exp_infos
            bucket = btor_insert_in_ptr_hash_table (exp_infos, real_exp);
            assert (bucket);
            bucket->data.asPtr = exp_info;
            
            // ???TODO removed  not needed nw may cause the clone assertion problem
            //count independent (not shared) subnodes
            exp_info->indsn = count_indep_subnodes(btor, real_exp);
            
            if (exp->kind == BTOR_BCOND_NODE) {
              exp_info->indsnl = count_indep_subnodes(btor, BTOR_REAL_ADDR_NODE(real_exp->e[1]));
              exp_info->indsnr = count_indep_subnodes(btor, BTOR_REAL_ADDR_NODE(real_exp->e[2]));
            }
            
            //assert(exp_info->indsn >= 1);
          } else {
            exp_info = bucket->data.asPtr;
          }
          assert (exp_info);
          assert (real_exp == exp_info->exp);
          if (BTOR_IS_INVERTED_NODE (exp)) 
          {
            exp_info->neg++;
          } else
          {
            exp_info->pos++;
          }
        }
      }
      cur = cur->next;
    }    
  }  
  //NOTE additional expression infos contain now valid number of pos, neg and indsn
}
/*------------------------------------------------------------------------*/

LkhdStats * 
new_lkhdstats(Btor *btor) {
  (void) btor;
  LkhdStats * stats;
  
  BTOR_CNEW(btor->mm, stats);
  stats->minsc = LLONG_MAX;
  return stats;
}

static void
update_lkhdstats(LkhdStats *stats, AddExpInfo * add_info, 
                 long long int (*heuristic)(AddExpInfo *), Msg *ms) 
{
  int score;
  BtorNode *exp = add_info->exp;  
  
  assert (BTOR_IS_REGULAR_NODE (exp));
  
  stats->psum += add_info->pos;
  stats->nsum += add_info->neg;
  stats->cnt++;
    
  add_info->sc.hsc = heuristic (add_info);
  score = add_info->sc.hsc;
  if (stats->maxsc < score) 
  {
    //stats->maxexp = add_info->pos >= add_info->neg ? BTOR_INVERT_NODE(exp) : exp;
    
    stats->maxexp = add_info->pos >= add_info->neg ? exp : BTOR_INVERT_NODE(exp);
    msg (ms, 4, "...heuristic new max exp %d score %d\n", BTOR_GET_ID_NODE (exp), score);
  }    
  if (stats->maxsc < score)
    stats->maxsc = score;
  if (stats->minsc > score) 
    stats->minsc = score;  
}

static void
fixup_lkhdstats(LkhdStats *stats) {
  if (stats->minsc == LLONG_MAX) 
  {
    assert (!stats->maxsc);
    stats->minsc = 0;
  }    
}

static void 
del_lkhdstats (Btor* btor, LkhdStats *stats)
{
  (void) btor;
  BTOR_DELETE (btor->mm, stats);
}

static void
prhead_lkhdstats(Msg *ms) {
  msg (ms, 2, "%-10s %10s %10s %10s %10s %10s %10s\n", 
     "name", "cnt", "pos occs", 
     "neg occs", "minscore", "maxscore", "maxexpr");  
}

static void
print_lkhdstats(LkhdStats *stats, char const *name, Msg *ms) {
  msg (ms, 2, "%-10s %10d %10d %10d %10d %10d %10d\n", 
       name, stats->cnt, stats->psum, stats->nsum, 
       stats->minsc, stats->maxsc, 
       stats->maxexp==NULL ? 0: BTOR_GET_ID_NODE (stats->maxexp));
}

/*------------------------------------------------------------------------*/

// multiply occurences with not-shared nodes
long long int 
heuristic_dummy (AddExpInfo *info)
{
  return info->sc.hsc;
}

// multiply occurences
long long int 
heuristic_mult (AddExpInfo *info)
{
  int res = info->pos * info->neg  ;//* info->indsn;
  return res;// > 100 ? res : 0;
}

long long int 
heuristictest_score (AddExpInfo *info)
{
  int res = info->neg  ;//* info->indsn;
  return res;// > 100 ? res : 0;
}

long long int 
heuristictest1_score (AddExpInfo *info)
{
  int res = info->pos + info->neg  ;//* info->indsn;
  return res;// > 100 ? res : 0;
}

// multiply occurences with not-shared nodes
long long int 
heuristic1_score (AddExpInfo *info)
{
  return (info->pos + info->neg) + info->pos * info->neg  * info->indsn ;
}

// count occurences
long long int 
heuristic_cnt (AddExpInfo *info)
{
  return info->neg + info->pos;
}

// count occurences plus no shared nodes
long long int 
heuristic_cntplusns (AddExpInfo *info)
{
  assert (BTOR_IS_REGULAR_NODE(info->exp));
  assert (info->exp->e[0]);
  int par = info->exp->e[0]->parents;
  return info->neg + info->pos + par + (info->indsnl + info->indsnr);
}

// pos occurences
long long int 
heuristic_pos (AddExpInfo *info)
{
  return info->pos;
}

// neg occurences
long long int 
heuristic_neg (AddExpInfo *info)
{
  return info->neg;
}

// multiply occurences with not-shared nodes
long long int 
heuristic_beq1v1 (AddExpInfo *info)
{
  return (info->pos * info->neg);// *info->indsn ;
}

// 
long long int 
heuristic_beq1vn (AddExpInfo *info)
{
  return (info->pos * info->neg);
}


void 
probe_reduction (Btor* btor, AddExpInfo *exp_info, Msg *ms)
{
  int psred, nsred, size;  // positive negative size reduction
  int pvred, nvred, vars;  // positive negative variable reduction
  
  BtorNode *exp = exp_info->exp;
  
  
  if (exp->kind == BTOR_BCOND_NODE) {
    exp = BTOR_REAL_ADDR_NODE(exp->e[0]);
  }
  
  
  assert (exp);
  assert (BTOR_IS_REGULAR_NODE(exp));
  
  //TODO probe condition
  
  // do boolean probe
  if (exp->len == 1)
  {
    // try to set positive and negative and messure reduction on binary nodes
    size = psred = nsred = sizeut(btor);
    vars = pvred = nvred = varcount(btor);
    int exp_id = BTOR_GET_ID_NODE (exp);
    assert (exp_id > 0);
        
    Btor* pcln = btor_clone_btor(btor);
    BtorNode* clnexp = BTOR_PEEK_STACK(pcln->nodes_id_table, exp_id);
    assert(BTOR_IS_REGULAR_NODE(clnexp));
    assert (psred == sizeut(pcln));
    btor_assert_exp (pcln, clnexp);
    exp_info->sc.pres = btor_simplify(pcln);
    psred = psred - sizeut(pcln);
    pvred = pvred - varcount(pcln);
    btor_delete_btor(pcln);    
    
    Btor* ncln = btor_clone_btor(btor);
    clnexp = BTOR_PEEK_STACK(ncln->nodes_id_table, exp_id);
    assert(BTOR_IS_REGULAR_NODE(clnexp));
    assert (nsred == sizeut(ncln));
    btor_assert_exp (ncln, BTOR_INVERT_NODE(clnexp));
    exp_info->sc.nres = btor_simplify(ncln);
    nsred = nsred - sizeut (ncln);
    nvred = nvred - varcount (ncln);
    btor_delete_btor(ncln);
        
    exp_info->sc.psr = psred * 100.0 / size;
    exp_info->sc.nsr = nsred * 100.0 / size;
    exp_info->sc.pvr = pvred * 100.0 / vars;
    exp_info->sc.nvr = nvred * 100.0 / vars;
    exp_info->sc.scr = (exp_info->sc.psr * exp_info->sc.nsr);
    
    if (exp_info->sc.pres != 0 || exp_info->sc.nres != 0) {
      msg(ms, 2, "probe (%d) pres %d(sred=%.2f%%vred=%.2f)\n", exp_id,
          exp_info->sc.pres, exp_info->sc.psr ,exp_info->sc.pvr);
      msg(ms, 2, "probe (%d) nres %d(sred=%.2f%%vred=%.2f)\n", exp_id,
          exp_info->sc.nres, exp_info->sc.nsr ,exp_info->sc.nvr);
      if (exp_info->sc.pres == 20 && exp_info->sc.nres == 20) {
        msg (ms, 1, "!!!! node can be solved immediatly"
              "by splitting on expression %d!!!! pres %d, nres %d\n", 
              exp_id, exp_info->sc.pres, exp_info->sc.nres);
      } else if (exp_info->sc.pres == 10 || exp_info->sc.nres == 10) {
        msg (ms, 1, "!!!! formula can be solved immediatly"
              "by splitting on expression %d!!!! pres %d, nres %d\n", 
              exp_id, exp_info->sc.pres, exp_info->sc.nres);
      }
    }
  }
  else 
  {
    //TODO just probe binary node is supported      
    assert (0);
  } 
}

/*------------------------------------------------------------------------*/



/*------------------------------------------------------------------------*/

/**
 * find a lookahead node by using add_exp_info table
 **/
static BtorNode * 
lkhd_find (Btor *btor, BtorPtrHashTable* add_exp_infos, 
           BtorPtrHashTable * remset, int pr, Msg *ms, LkhdT lkhdtype)
{
  size_t i;
  LkhdStats *snodes [BTOR_NUM_OPS_NODE];
  LkhdStats *slkhd [LKHD_ALL];
  
  //init stats 
  for ( i = 0; i < BTOR_NUM_OPS_NODE; i++) 
  {
    snodes[i] = new_lkhdstats (btor);
  }
  for ( i = 0; i < LKHD_ALL; i++) 
  {
    slkhd[i] = new_lkhdstats (btor);
  }
  
  BtorPtrHashBucket * bucket = add_exp_infos->first;
  
  int maxprobesc = 0;
  BtorNode *maxprobexp = 0;
  int ph = 0;
    
  msg (ms, 3, "#begin score table\n");
  
  while (bucket) {
    BtorNode* exp = bucket->key;
    assert (BTOR_IS_REGULAR_NODE(exp));
            
    assert (!exp->constraint);
    
    if (!exp->constraint) 
    {  
      AddExpInfo * exp_info = (AddExpInfo *)bucket->data.asPtr;
      
      // all exp with len=1
      if (exp->len == 1) {
        if (BTOR_IS_BV_EQ_NODE(exp)) {
          assert (exp->e[0]);
          assert (exp->e[1]);
          BtorNode *e0 = BTOR_REAL_ADDR_NODE (exp->e[0]);
          BtorNode *e1 = BTOR_REAL_ADDR_NODE (exp->e[1]);
          // contains var with len > 1
          if (e0->len > 1 && (BTOR_IS_BV_VAR_NODE(e0) || BTOR_IS_BV_VAR_NODE(e1))) {
            update_lkhdstats (slkhd[LKHD_BEQ1VN], exp_info, /*heuristictest_score*/ heuristic_beq1vn, ms);
            if (lkhdtype == LKHD_BEQ1VN || lkhdtype >= LKHD_ALL) {
              if (pr) {
                probe_reduction(btor, exp_info, ms);                
                if (maxprobesc < exp_info->sc.scr) {
                  maxprobesc = exp_info->sc.scr;
                  maxprobexp = exp_info->exp;
                }
              }
              if (ph++%printhead == 0)
                msg_exp_head(3, exp_info, pr, ms);
              msg_exp(3, exp_info, ms, lkhdtype);
            }
          }
          // contains var with len = 1
          else if (e0->len == 1 && (BTOR_IS_BV_VAR_NODE(e0) || BTOR_IS_BV_VAR_NODE(e1))) {
            assert (e1->len == 1);
            update_lkhdstats (slkhd[LKHD_BEQ1V1], exp_info, heuristic_beq1v1, ms);
            if (lkhdtype == LKHD_BEQ1V1 || lkhdtype >= LKHD_ALL) {
              if (pr) {
                 probe_reduction(btor, exp_info, ms);
                if (maxprobesc < exp_info->sc.scr) {
                  maxprobesc = exp_info->sc.scr;
                  maxprobexp = exp_info->exp;
                }
              }
              if (ph++%printhead == 0)
                msg_exp_head(3, exp_info, pr, ms);
              msg_exp(3, exp_info, ms, lkhdtype);
            }
          }
          // all others bit equalities without variable
          else {        
            // general beq
            update_lkhdstats (slkhd[LKHD_BEQ1OTHER], exp_info, heuristic_mult, ms);
            if (lkhdtype == LKHD_BEQ1OTHER || lkhdtype >= LKHD_ALL) {
              if (pr) {
                probe_reduction(btor, exp_info, ms);
                if (maxprobesc < exp_info->sc.scr) {
                  maxprobesc = exp_info->sc.scr;
                  maxprobexp = exp_info->exp;
                } 
              }
              if (ph++%printhead == 0)
                msg_exp_head(3, exp_info, pr, ms);
              msg_exp(3, exp_info, ms, lkhdtype);
            }
          }
        }
        // VAR1
        else if (exp->kind == BTOR_BV_VAR_NODE)
        { 
          update_lkhdstats (slkhd[LKHD_VAR1], exp_info, heuristic_cnt, ms);
          if (lkhdtype == LKHD_VAR1 || lkhdtype >= LKHD_ALL) {
            if (pr) {
              probe_reduction(btor, exp_info, ms);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              } 
            }
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }
        }
        // SLICE1
        else if (exp->kind == BTOR_SLICE_NODE) 
        { 
          update_lkhdstats (slkhd[LKHD_SLICE1], exp_info, heuristic_cnt, ms);
          if (lkhdtype == LKHD_SLICE1 || lkhdtype >= LKHD_ALL) {
            if (pr) {
              probe_reduction(btor, exp_info, ms);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              }
            }
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }        
        }
        // AND1
        else if (exp->kind == BTOR_AND_NODE)
        {          
          //if (!btor_find_in_ptr_hash_table(remset, exp_info->exp)) {
            update_lkhdstats (slkhd[LKHD_AND1], exp_info, heuristic_mult, ms);
          //} else {
          //  printf("*********** %d is already in remset\n", exp_info->exp->id);
          //}
          if (lkhdtype == LKHD_AND1 || lkhdtype >= LKHD_ALL) {
            if (pr) {
              probe_reduction(btor, exp_info, ms);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              }
            }
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }        
        }
        // ULT1
        else if (exp->kind == BTOR_ULT_NODE)
        { 
          update_lkhdstats (slkhd[LKHD_ULTN1], exp_info, heuristic_mult, ms);
          if (lkhdtype == LKHD_ULTN1 || lkhdtype >= LKHD_ALL) {
            if (pr) {
              probe_reduction(btor, exp_info, ms);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              }
            }
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }        
        }
        // OTHER1 everything else exept BV_CONS
        else if (exp->kind != BTOR_BV_CONST_NODE)
        {
          update_lkhdstats (slkhd[LKHD_OTHER1], exp_info, heuristic_mult, ms);
          if (lkhdtype == LKHD_OTHER1 || lkhdtype >= LKHD_ALL) {
            if (pr) {
              probe_reduction(btor, exp_info, ms);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              }
            }
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }  
        }
      } else if (exp->kind == BTOR_BCOND_NODE)
      {
          update_lkhdstats (slkhd[LKHD_BCOND], exp_info, heuristic_cntplusns, ms);
          if (lkhdtype == LKHD_BCOND || lkhdtype >= LKHD_ALL) {
          // here no probing is necessary is done by probing the one bit nodes
          /*
            if (probe) {
              proberes = probe_reduction(btor, exp_info);
              if (maxprobesc < exp_info->sc.scr) {
                maxprobesc = exp_info->sc.scr;
                maxprobexp = exp_info->exp;
              }
            }
            */
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }  
        
      }
      // MULN
      else if (exp->kind == BTOR_MUL_NODE) 
      {
        assert (exp->e[0]);
        assert (exp->e[1]);
        BtorNode *e0 = exp->e[0];
        BtorNode *e1 = exp->e[1];
        BtorNode *r_e0 = BTOR_REAL_ADDR_NODE (e0);
        BtorNode *r_e1 = BTOR_REAL_ADDR_NODE (e1);
        
        if ( (BTOR_IS_BV_VAR_NODE(r_e0) && 
            !boolector_is_exp_assert_eq_ne_zero(btor, BTOR_EXPORT_BOOLECTOR_NODE(e0)))
          || (BTOR_IS_BV_VAR_NODE(r_e1) && 
            !boolector_is_exp_assert_eq_ne_zero(btor, BTOR_EXPORT_BOOLECTOR_NODE(e1))) ) 
        {
          update_lkhdstats (slkhd[LKHD_MULN0], exp_info, heuristic_cnt, ms);
          if (lkhdtype == LKHD_MULN0 || lkhdtype >= LKHD_ALL) {
            //TODO does probing make sense on MUL is there a reduction to messure?
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }  
        }        
        if ( (BTOR_IS_BV_VAR_NODE(r_e0) && 
            !boolector_is_exp_assert_eq_ne_one(btor, BTOR_EXPORT_BOOLECTOR_NODE(e0)))
          || (BTOR_IS_BV_VAR_NODE(r_e1) && 
            !boolector_is_exp_assert_eq_ne_one(btor, BTOR_EXPORT_BOOLECTOR_NODE(e1))) ) 
        {
          update_lkhdstats (slkhd[LKHD_MULN1], exp_info, heuristic_cnt, ms);
          if (lkhdtype == LKHD_MULN1 || lkhdtype >= LKHD_ALL) {
            //TODO does probing make sense on MUL is there a reduction to messure?
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }  
        }
        
        //check if some bits are still to split
        // NOTE this did not work btor_fixed_exp_at sometimes returned wrong
        // results??
        
        /*
        int j;
        msg (ms, 0, "*** exp id %d %s; e0 id %d %s; e1 id %d %s\n", 
             exp->id, BtorKindToName[exp->kind],
             e0->id, BtorKindToName[e0->kind],
             e1->id, BtorKindToName[e1->kind]
            );
        msg (ms, 0, "");
        for (j = 0; j < exp->len; j++) 
        {
          msgwop (ms, 0, "%3d ", btor_fixed_exp_at(btor, exp, j));
        }
        msgwop (ms, 0, "\n");
        msg (ms, 0, "");
        for (j = 0; j < exp->len; j++) 
        {
          msgwop (ms, 0, "%3d ", btor_fixed_exp_at(btor, e0, j));
        }
        msgwop (ms, 0, "\n");
        msg (ms, 0, "");
        for (j = 0; j < exp->len; j++) 
        {
          msgwop (ms, 0, "%3d ", btor_fixed_exp_at(btor, e1, j));
        }
        msgwop (ms, 0, "\n");
        */
        
        
        /*
        BtorPtrHashBucket * bu = remset->first;
        msg(ms ,0, "*** remset: ");
        while (bu) {
          msgwop(ms, 0, "%p %d;", bu->key, *((int*)bu->key));
          bu = bu->next;    
        }
        msgwop(ms ,0, "\n");
        */
        // check if last bit is set in remset!!
        int id = exp->id;
        BtorPtrHashBucket *b = btor_find_in_ptr_hash_table(remset, &id);
        if (!b) {
          update_lkhdstats (slkhd[LKHD_MULNBIT], exp_info, heuristic_cnt, ms);
        } else {
          //current split bit
          int csb = b->data.asInt + 1;
          // just split LSB in this implementation csb < 2 splits on two LSB's
          while (csb < exp->len && csb < 1) {
            if (!btor_fixed_exp_at(btor, exp, csb)) {
              update_lkhdstats (slkhd[LKHD_MULNBIT], exp_info, heuristic_cnt, ms);
              b->data.asInt = csb;
              break;
            }
            csb++;
          }
        }
        
        if (lkhdtype == LKHD_MULNBIT || lkhdtype >= LKHD_ALL) {
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
        }
        
      }
      // ADDN
      else if (exp->kind == BTOR_ADD_NODE) 
      {
        assert (exp->e[0]);
        assert (exp->e[1]);
        BtorNode *e0 = exp->e[0];
        BtorNode *e1 = exp->e[1];
        BtorNode *r_e0 = BTOR_REAL_ADDR_NODE (e0);
        BtorNode *r_e1 = BTOR_REAL_ADDR_NODE (e1);
        
        if ( (BTOR_IS_BV_VAR_NODE(r_e0) && 
            !boolector_is_exp_assert_eq_ne_zero(btor, BTOR_EXPORT_BOOLECTOR_NODE(e0)))
          || (BTOR_IS_BV_VAR_NODE(r_e1) && 
            !boolector_is_exp_assert_eq_ne_zero(btor, BTOR_EXPORT_BOOLECTOR_NODE(e1))) ) 
        {
          update_lkhdstats (slkhd[LKHD_ADDN0], exp_info, heuristic_cnt, ms);
          if (lkhdtype == LKHD_ADDN0 || lkhdtype >= LKHD_ALL) {
            //TODO does probing make sense on ADD is there a reduction to messure?
            if (ph++%printhead == 0)
              msg_exp_head(3, exp_info, pr, ms);
            msg_exp(3, exp_info, ms, lkhdtype);
          }  
        }
        int id = exp->id;
        BtorPtrHashBucket *b = btor_find_in_ptr_hash_table(remset, &id);
        if (!b) {
          update_lkhdstats (slkhd[LKHD_ADDNBIT], exp_info, heuristic_cnt, ms);
        } else {
          //current split bit
          int csb = b->data.asInt + 1;
          while (csb < exp->len && csb < 1) {
            if (!btor_fixed_exp_at(btor, exp, csb)) {
              update_lkhdstats (slkhd[LKHD_ADDNBIT], exp_info, heuristic_cnt, ms);
              b->data.asInt = csb;
              break;
            }
            csb++;
          }
        }
      }
      
      update_lkhdstats (snodes[exp->kind], exp_info, heuristic_dummy, ms);
      
      if (pr) {
        int pres = exp_info->sc.pres;
        int nres = exp_info->sc.nres;
        assert (pres == 0 || pres == 10 || pres == 20);
        assert (nres == 0 || nres == 10 || nres == 20);
        //failed literal or solution found return immediatly
        if (pres != 0 || nres != 0) {
          // stop lookahead and return failed literal
          if (nres == 20 || nres == 10) {
            maxprobexp = BTOR_INVERT_NODE(exp);  // return negative literal phase
          } else {
            maxprobexp = exp;
          
          }
          break;
        }
      }      
    }    
    bucket = bucket->next;
  }
  msg (ms, 3, "#end score table\n");
    
  for ( i = 0; i < BTOR_NUM_OPS_NODE; i++) 
  {
    fixup_lkhdstats(snodes[i]);
  }   
  for ( i = 0; i < LKHD_ALL; i++) 
  {
    fixup_lkhdstats(slkhd[i]);
  }
  
  BtorNode* exp;
  if (!pr)
  {
    if (lkhdtype < LKHD_ALL)
      exp = slkhd[lkhdtype]->maxexp;    
    else 
    {
      exp = 0;
      if (lkhdtype == LKHD_ALL) {
        exp = slkhd[LKHD_BEQ1VN]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BCOND]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_SLICE1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_VAR1]->maxexp;
        if (exp == 0)
           exp = slkhd[LKHD_MULNBIT]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BEQ1OTHER]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_AND1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_ULTN1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_OTHER1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BEQ1V1]->maxexp;
      } else if (lkhdtype == LKHD_ALL1) {
        
        
        if (exp == 0)
          exp = slkhd[LKHD_MULN0]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_MULN1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_ADDN0]->maxexp;
        if (exp == 0)
           exp = slkhd[LKHD_MULNBIT]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BEQ1VN]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BCOND]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_SLICE1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_VAR1]->maxexp;
        if (exp == 0)
           exp = slkhd[LKHD_MULNBIT]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BEQ1OTHER]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_AND1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_ULTN1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_OTHER1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_BEQ1V1]->maxexp;
        
      } else if (lkhdtype == LKHD_ALL2) {
        // rand is not threadsafe
        // TODO improve random lookahead selection
        int begin = rand() % LKHD_ALL;
        int next = begin;
        do {
          next = (next + 1) % LKHD_ALL; 
          if (i == LKHD_MULN1 || i == LKHD_MULNBIT || i == LKHD_ADDNBIT)
            continue;
          if (slkhd[next]->maxsc > 0) {
            exp = slkhd[next]->maxexp;
            break;
          }
        } while (next != begin);
      } else if (lkhdtype == LKHD_ALL3) {
        
        int i;
        double maxcs = 0.0;
        
        for (i = 0; i < LKHD_ALL; i++) {
          if (i == LKHD_MULN1 || i == LKHD_MULNBIT || i == LKHD_ADDNBIT
            || i == LKHD_MULN0 || i == LKHD_ADDN0 )
            continue;
          
          if (slkhd[i]->maxexp == 0)
            continue;
          
          BtorPtrHashBucket *bucket = btor_find_in_ptr_hash_table(add_exp_infos, BTOR_REAL_ADDR_NODE(slkhd[i]->maxexp));
          assert (bucket);
          AddExpInfo *exp_info = (AddExpInfo *)bucket->data.asPtr;
          
          probe_reduction(btor, exp_info, ms);
          //TODO printing
          msg (ms ,1 , "probing return value\n");
          msg_exp_head(2, exp_info, pr, ms);
          msg_exp(2, exp_info, ms, lkhdtype);
          if (exp_info->sc.scr > maxcs) {
            exp = slkhd[i]->maxexp;
            maxcs = exp_info->sc.scr;
          }          
        }          
        if (exp == 0)
          exp = slkhd[LKHD_MULN0]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_MULN1]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_MULNBIT]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_ADDN0]->maxexp;
        if (exp == 0)
          exp = slkhd[LKHD_ADDNBIT]->maxexp;
      
      }     
      
      // this works good by chance for isqrtaddnoifinvalid...
      /*
      if (exp == 0) {
        if (slkhd[LKHD_MULN1]->maxsc > slkhd[LKHD_MULN0]->maxsc) 
        {
          if (slkhd[LKHD_MULNBIT]->maxsc > slkhd[LKHD_MULN1]->maxsc)
          {
            //exp = slkhd[LKHD_MULNBIT]->maxexp;
          } 
          else 
          {
            //exp = slkhd[LKHD_MULN1]->maxexp;
          }
        } 
        else 
        {
          exp =slkhd[LKHD_MULN0]->maxexp;
        }
      }
      if (exp == 0) {
        if (slkhd[LKHD_ADDNBIT]->maxsc > slkhd[LKHD_ADDN0]->maxsc)
        {
          exp = slkhd[LKHD_ADDNBIT]->maxexp;
        }
        else 
        {
          exp = slkhd[LKHD_ADDN0]->maxexp;
        }
      }
      */
    } 
  } else 
  {
    exp = maxprobexp;
  }
  
  
  prhead_lkhdstats(ms);
  for (i = 0; i < LKHD_ALL; i++) {
    print_lkhdstats(slkhd[i], LkhdKindToName[i], ms);   
    if ((exp != 0 && lkhdtype == i) || 
      (lkhdtype >= i && exp != 0 && exp == slkhd[i]->maxexp)) {
      msg(ms, 1, "selected lookahead type %s \n", LkhdKindToName[i]);
    }
    del_lkhdstats(btor, slkhd[i]);
  }
  
  prhead_lkhdstats(ms);
  //int max = 0;
  for (i = 0; i < BTOR_NUM_OPS_NODE; i++) {
    print_lkhdstats(snodes[i], BtorKindToName[i], ms); 
    del_lkhdstats(btor, snodes[i]);
  }
  
  return exp;
}

static void 
delete_add_exp_infos (BtorPtrHashTable* add_exp_infos)
{
  BtorPtrHashBucket * bucket = add_exp_infos->first;
  while (bucket) {
    BtorNode* exp = bucket->key;
    assert (BTOR_IS_REGULAR_NODE (exp));
    AddExpInfo * add_exp_info = (AddExpInfo *)bucket->data.asPtr;
    BTOR_DELETE(add_exp_infos->mem, add_exp_info);
    bucket = bucket->next;
  }
}

/*------------------------------------------------------------------------*/
static void 
msg_exp_head (int level, AddExpInfo * add_info, int pr, Msg *ms)
{
  if (level <= vrb(ms))
  {
    msg (ms, level, "%-6s; %7s; %3s; %3s; %3s; %3s; ", 
         "id", "kind", "ref", "len", "cle", "par");
    if (add_info != NULL) {
      msgwop (ms, level, "%3s; %3s; %3s; %3s; %3s; %3s; %6s; ",
          "pos", "neg", "ns", "nsl", "nsr", "hsc", "lkind");
      if (pr) {
        msgwop (ms, level, "%5s; %5s; %5s; %5s; %6s; ", 
            "psr", "nsr", "pvr", "nvr", "rsc");
      }
    }
    msgwop(ms ,level, "\n");      
  }
}
static void 
msg_exp(int level, AddExpInfo * add_info, Msg *ms, LkhdT lkhdtype) 
{
  BtorNode *exp = add_info->exp;
  assert(BTOR_IS_REGULAR_NODE(exp));
  if (level <= vrb(ms)) 
  {
    int clen = exp->arity > 0 ? BTOR_REAL_ADDR_NODE(exp->e[0])->len : 0;
    msg (ms, level, "%-6d; %7s; %3d; %3d; %3d; %3d; ", 
         exp->id, BtorKindToName[exp->kind], exp->refs, exp->len, clen,  
         exp->parents);
    if (add_info != NULL) 
    {
      LkhdScore sc = add_info->sc;
      
      msgwop (ms, level, "%3d; %3d; %3d; %3d; %3d; %3d; %6s; ", 
              add_info->pos, add_info->neg, 
              add_info->indsn, add_info->indsnl, add_info->indsnr,
              sc.hsc, LkhdKindToName[lkhdtype]);
      if (1) {
        msgwop (ms, level, "%5.2f; %5.2f; %5.2f; %5.2f; %6.2f; ", 
          sc.psr, sc.nsr, sc.pvr, sc.nvr, sc.scr);
      }
    }
    msgwop(ms, level, "\n");
  }
}

/*------------------------------------------------------------------------*/
// old implemenation

// count positive and negative occurances of regular node expression
static void 
count_occurences (BtorNode* exp, BtorPtrHashTable* constr_children, 
                  int* pos, int* neg )
{
  int i ;
  BtorNodeIterator iter;
  *pos = 0, *neg = 0;
  
  assert(exp);
  assert(BTOR_IS_REGULAR_NODE(exp));
  assert(constr_children);
  
  // iterate trough parent list
  init_full_parent_iterator(&iter, exp);
  while (has_next_parent_full_parent_iterator(&iter)) 
  {
    BtorNode *parent = next_parent_full_parent_iterator(&iter);
    assert (BTOR_IS_REGULAR_NODE(parent));
    
    // just count occurences if parent is in constraint_children table
    if ( btor_find_in_ptr_hash_table(constr_children, parent))
    {
      //find the child
      for (i = 0; i < parent->arity; i++)
      {
        // find exp in parameters of parent
        if (exp == BTOR_REAL_ADDR_NODE(parent->e[i]))
        {
          if (BTOR_IS_INVERTED_NODE (parent->e[i]))
          {
            (*neg)++;
          } else 
          {
            (*pos)++;
          }
        }
      }
      // the parent have to contain the child at least once 
      assert (*pos > 0 || *neg > 0);
    }
  }
}

//this was the very first implemenation of lookahead
BtorNode *
count_on_the_fly (Btor *btor, BtorPtrHashTable *constr_children, Msg *ms)
{
  int i, pos, neg; 
  long int max_score = 0;
  BtorNode *lkhd = NULL;
  
  for ( i = 0; i < btor->nodes_unique_table.size; i++) {
    BtorNode *cur =  btor->nodes_unique_table.chains[i];    
    while (cur) 
    {
      // check -- only regular nodes should be in the unique table
      assert (BTOR_IS_REGULAR_NODE(cur));
            
      // just take nodes of constr_children
      // just take non top level constraint nodes
      // just take BV nodes as candidates 
      // TODO adapt to equalities ARRAY NODES
      if (btor_find_in_ptr_hash_table(constr_children, cur) 
        && !cur->constraint 
        //&& BTOR_IS_ARRAY_OR_BV_EQ_NODE (cur)
        //&& BTOR_IS_ULT_NODE (cur)
        && cur->len == 1 ) 
      {
        assert (cur->len == 1);
        count_occurences(cur, constr_children, &pos, &neg);
        long int score = (pos + neg) + (pos * neg);
        msg (ms , 3, "node %d pos=%d, neg=%d score=%ld, refs=%d ", 
                BTOR_GET_ID_NODE(cur), pos, neg, score, cur->refs);
      
        // if there is at least one occurence save node with highest score
        if ( /*(pos > 0 || neg > 0) && */
          score  > max_score) 
        {
          max_score = score; 
          if (neg > pos)
          {  
            lkhd = BTOR_INVERT_NODE(cur);
          } else {
            lkhd = cur;
          }
          msgwop (ms , 3, "...new lookahead candidate: %d", 
                  BTOR_GET_ID_NODE(lkhd));
        }
      msgwop (ms, 3, "\n");
      }      
      cur = cur->next;
    }
  }
  return lkhd;
}

/*------------------------------------------------------------------------*/
// failed literal reduction
/*------------------------------------------------------------------------*/

// return 10 SAT, 20 UNSAT, 30 new round (failed literals are applied), 
static int 
apply_literal (Btor* btor, AddExpInfo *exp_info, Msg *ms) {
  int ph = 0, res = 0;
  BtorNode * cur = exp_info->exp;
  
  assert (BTOR_IS_REGULAR_NODE(cur));    
  
  if (!cur->constraint && cur->len == 1 && cur->kind != BTOR_BV_CONST_NODE) {
    exp_info->exp = cur;
    probe_reduction(btor, exp_info, ms);
    if (ph++%printhead == 0)
      msg_exp_head(3, exp_info, 1, ms);
    msg_exp(3, exp_info, ms, 0);
    int nres = exp_info->sc.nres;
    int pres = exp_info->sc.pres;
    if (nres == 10 || pres == 10) {
      return 10;
    } else if (nres == 20 && pres == 20) {
      return 20;
    } else if (nres == 20) {
      btor_assert_exp(btor, cur);
      res = btor_simplify(btor);
      assert (res == 0);
      return 30;
    } else if (pres == 20) {
      btor_assert_exp(btor, BTOR_INVERT_NODE(cur));
      res = btor_simplify(btor);
      assert (res == 0);
      return 30;
    } else {
      assert (nres == 0 && pres == 0);
    }
  }
  return res;
}

/*
// return 10 SAT, 20 UNSAT, 30 new round (failed literals are applied), 
// 0 no failed literals found (fix point)
// traverse unique table
static int 
find_and_apply_failed_literals_ut (Btor * btor, AddExpInfo *exp_info, Msg *ms) {
  int i, res;
  msg(ms, 2, "start new round\n");
  //run through unique table
  for (i = 0; i < btor->nodes_unique_table.size; i++) {
    BtorNode *cur =  btor->nodes_unique_table.chains[i];
    // follow collision chain
    while (cur) {
      assert (BTOR_IS_REGULAR_NODE(cur));      
      exp_info->exp = cur;
      res = apply_literal(btor, exp_info, ms);
      if (res != 0) {
        goto FINISHED;
      }
      cur = cur->next;
    }    
  }
FINISHED: 
  return res;
}
*/

/**
 * find and apply failed literals from top to bottom
 */
static int
find_and_apply_failed_literals_dag (Btor *btor, 
                AddExpInfo *exp_info, 
                Msg *ms) 
{
  int i, res = 0; 
  BtorNodePtrQueue queue;
  BtorPtrHashTable *visited;
  BtorPtrHashBucket *bucket;
  BtorNode *exp;
    
  msg(ms, 2, "start new round\n");
  
  BTOR_INIT_QUEUE (queue);
    
  assert(btor);
  
  visited = btor_new_ptr_hash_table(btor->mm,
                        (BtorHashPtr) btor_hash_exp_by_id,
                        (BtorCmpPtr) btor_compare_exp_by_id);
  
  
  bucket = btor->unsynthesized_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
    assert (exp->constraint);
    if (!btor_find_in_ptr_hash_table(visited, exp))
    {
      btor_insert_in_ptr_hash_table(visited, exp);
      BTOR_ENQUEUE (btor->mm, queue, exp);
    }
    bucket = bucket->next;
  }
  bucket = btor->synthesized_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
    assert (exp->constraint);
    if (!btor_find_in_ptr_hash_table(visited, exp))
    {
      btor_insert_in_ptr_hash_table(visited, exp);
      BTOR_ENQUEUE (btor->mm, queue, exp);
    }
    bucket = bucket->next;
  }
  bucket = btor->embedded_constraints->first;
  while (bucket) 
  {
    exp = bucket->key;
    assert (exp);    
    exp = BTOR_REAL_ADDR_NODE(exp);
    assert (exp->btor == btor);
    assert (exp->constraint);
    if (!btor_find_in_ptr_hash_table(visited, exp))
    {
      btor_insert_in_ptr_hash_table(visited, exp);
      BTOR_ENQUEUE (btor->mm, queue, exp);
    }
    bucket = bucket->next;
  }
    
  while (!BTOR_EMPTY_QUEUE(queue))
  { 
    BtorNode *child;
    BtorNode *cur = BTOR_DEQUEUE (queue);
    exp_info->exp = cur;
    res = apply_literal(btor, exp_info, ms);
    if (res != 0) {
      break;
    }
    
    assert (BTOR_IS_REGULAR_NODE(cur));
    for (i = 0; i < exp_info->exp->arity; i++) 
    {
      child = BTOR_REAL_ADDR_NODE(cur->e[i]);
      if (!btor_find_in_ptr_hash_table(visited, child))
      {
        btor_insert_in_ptr_hash_table(visited, child);
        BTOR_ENQUEUE (btor->mm, queue, child);
      }
    }        
  }
  BTOR_RELEASE_QUEUE (btor->mm, queue);
  btor_delete_ptr_hash_table(visited);  
  return res;
}

// probe all boolean literals and apply the opossite of failed ones 
// return result if result found else 0
int 
btor_fl_reduction(Btor* btor, int v, int *fl)
{
  AddExpInfo *exp_info;
  int res;
  
  *fl = 0;
    
  BTOR_NEW(btor->mm, exp_info);
  BTOR_CLR(exp_info);
  Msg *ms = newmsg (btor, "flred");
  setvrb(ms, v);  
  
  // apply fl until fixpoint
  do {
    res = find_and_apply_failed_literals_dag(btor, exp_info, ms);
    if (res != 0) (*fl)++;
  } while (res == 30) ;
  
  BTOR_DELETE(btor->mm, exp_info); 
  delmsg(btor, ms);
  return res;
}

