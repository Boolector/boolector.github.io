/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */

#include "btorparse.h"
#include "btoriter.h"
#include "btorabort.h"
#include "btorconst.h"
#include "pboolector.h"
#include "btorlkhd.h"
#include "btorpbtor.h"
#include "parser/btorbtor.h"
#include "parser/btorsmt2.h"

/*------------------------------------------------------------------------*/

//TODO insert trapi.

// return copy or null
BoolectorNode *
boolector_lookahead (Btor * btor, int v, int type, int pr,
                      BtorPtrHashTable * remset)
{  
  BtorNode *exp;
  BoolectorNode *ret = NULL;
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  exp = btor_lkhd (btor, v, type, pr, remset);
  
  if (exp) {
    assert (BTOR_REAL_ADDR_NODE(exp)->btor == btor);
    btor->external_refs++;
    exp = btor_copy_exp (btor, exp);
    BTOR_REAL_ADDR_NODE (exp)->ext_refs += 1;
    ret = BTOR_EXPORT_BOOLECTOR_NODE(exp);
  }
  return ret;
}

// return copy or null
BoolectorNode *
boolector_lookahead_simple (Btor * btor)
{  
  BtorNode *exp;
  BoolectorNode *ret = NULL;
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  exp = btor_lkhd_simple (btor);
  
  if (exp) {
    assert (BTOR_REAL_ADDR_NODE(exp)->btor == btor);
    btor->external_refs++;
    exp = btor_copy_exp (btor, exp);
    BTOR_REAL_ADDR_NODE (exp)->ext_refs += 1;
    ret = BTOR_EXPORT_BOOLECTOR_NODE(exp);
  }
  return ret;
}

int boolector_failed_literal_reduction(Btor* btor, int v, int *fl)
{ 
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  return btor_fl_reduction(btor, v, fl);
}


int
boolector_get_size (Btor *btor)
{
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  return btor->nodes_unique_table.num_elements;
}

int 
boolector_get_vars (Btor * btor) 
{
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  return btor->bv_vars->count;
}

BoolectorNode *
boolector_get_exp_by_id (Btor * btor, int id)
{
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);  
  
  BtorNode *exp = BTOR_PEEK_STACK(btor->nodes_id_table, abs(id));
  assert (BTOR_IS_REGULAR_NODE (exp));
  if (id < 0) 
  {
    exp = BTOR_INVERT_NODE(exp);
  }
  
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
    
  btor->external_refs++;
  exp = btor_copy_exp (btor, exp);
  BTOR_REAL_ADDR_NODE (exp)->ext_refs += 1;
  
  return BTOR_EXPORT_BOOLECTOR_NODE(exp); 
}

int
boolector_is_bcond_exp(Btor *btor, BoolectorNode * node) {
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  return real->kind == BTOR_BCOND_NODE;
}

int
boolector_is_mul_exp(Btor *btor, BoolectorNode * node) {
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  return real->kind == BTOR_MUL_NODE;
}

int
boolector_is_add_exp(Btor *btor, BoolectorNode * node) {
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  return real->kind == BTOR_ADD_NODE;
}

// return copy
BoolectorNode *
boolector_get_param0 (Btor * btor, BoolectorNode * node) 
{
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  assert (real);
  assert (real->e[0]);
  exp = real->e[0];  
    
  btor->external_refs++;
  exp = btor_copy_exp (btor, exp);
  BTOR_REAL_ADDR_NODE (exp)->ext_refs += 1;
  
  return BTOR_EXPORT_BOOLECTOR_NODE(exp); 
}

// return copy
BoolectorNode *
boolector_get_param1(Btor * btor, BoolectorNode * node) {
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  assert (real);
  assert (real->e[1]);
  exp = real->e[1];  
    
  btor->external_refs++;
  exp = btor_copy_exp (btor, exp);
  BTOR_REAL_ADDR_NODE (exp)->ext_refs += 1;
  
  return BTOR_EXPORT_BOOLECTOR_NODE(exp); 
}


static int
is_const_zero_exp (Btor * btor, BtorNode * exp)
{
  int result;
  BtorNode *real_exp;

  assert (btor);
  assert (exp);

  exp = btor_simplify_exp (btor, exp);

  if (!BTOR_IS_BV_CONST_NODE (BTOR_REAL_ADDR_NODE (exp)))
    return 0;

  if (BTOR_IS_INVERTED_NODE (exp))
    {
      real_exp = BTOR_REAL_ADDR_NODE (exp);
      result = btor_is_ones_const (real_exp->bits);
    }
  else
    result = btor_is_zero_const (exp->bits);

  return result;
}

static int
is_const_one_exp (Btor * btor, BtorNode * exp)
{
  int result;
  BtorNode *real_exp;

  assert (btor);
  assert (exp);
  exp = btor_simplify_exp (btor, exp);

  if (!BTOR_IS_BV_CONST_NODE (BTOR_REAL_ADDR_NODE (exp)))
    return 0;

  real_exp = BTOR_REAL_ADDR_NODE (exp);
  if (BTOR_IS_INVERTED_NODE (exp))
    btor_invert_const (btor->mm, real_exp->bits);
  result = btor_is_special_const (real_exp->bits) == BTOR_SPECIAL_CONST_ONE;
  if (BTOR_IS_INVERTED_NODE (exp))
    btor_invert_const (btor->mm, real_exp->bits);

  return result;
}

int 
boolector_is_exp_assert_eq_ne_zero (Btor * btor, BoolectorNode * node)
{
  BtorNode * exp, * simp, * real;
  int res = 0;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  
  BtorNodeIterator iter;
  init_full_parent_iterator(&iter, real);
  while (has_next_parent_full_parent_iterator(&iter)) 
  {
    BtorNode *parent = next_parent_full_parent_iterator(&iter);
    assert (BTOR_IS_REGULAR_NODE(parent));
    
    if (parent->constraint && parent->kind == BTOR_BEQ_NODE)
    {      
      if (parent->e[0] == simp) 
      {
        if (is_const_zero_exp(btor, parent->e[1])) 
        {
          res = 1;
          break;
        }
      } 
      else if (parent->e[0] == BTOR_INVERT_NODE(simp)) {
        if (is_const_zero_exp(btor, BTOR_INVERT_NODE(parent->e[1]))) 
        {
          res = 1;
          break;
        }
      }
      else if (parent->e[1] == exp) 
      {
        if (is_const_zero_exp(btor, parent->e[0])) 
        {
          res = 1;
          break;
        }
      } 
      else if (parent->e[1] == BTOR_INVERT_NODE(simp)) {
        if (is_const_one_exp(btor, BTOR_INVERT_NODE(parent->e[0]))) 
        {
          res = 1;
          break;
        }
      } 
      else 
      {
        assert (BTOR_REAL_ADDR_NODE (parent->e[0]) != real &&
                BTOR_REAL_ADDR_NODE (parent->e[1]) != real);
      }        
    }
  }
  return res;
}

int 
boolector_is_exp_assert_eq_ne_one (Btor * btor, BoolectorNode * node)
{  
  BtorNode * exp, * simp, * real;
  int res = 0;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  
  BtorNodeIterator iter;
  init_full_parent_iterator(&iter, real);
  while (has_next_parent_full_parent_iterator(&iter)) 
  {
    BtorNode *parent = next_parent_full_parent_iterator(&iter);
    assert (BTOR_IS_REGULAR_NODE(parent));
    
    if (parent->constraint && parent->kind == BTOR_BEQ_NODE)
    {      
      if (parent->e[0] == simp) 
      {
        if (is_const_one_exp(btor, parent->e[1])) 
        {
          res = 1;
          break;
        }
      } 
      else if (parent->e[0] == BTOR_INVERT_NODE(simp)) {
        if (is_const_one_exp(btor, BTOR_INVERT_NODE(parent->e[1]))) 
        {
          res = 1;
          break;
        }
      }
      else if (parent->e[1] == exp) 
      {
        if (is_const_one_exp(btor, parent->e[0])) 
        {
          res = 1;
          break;
        }
      } 
      else if (parent->e[1] == BTOR_INVERT_NODE(simp)) {
        if (is_const_one_exp(btor, BTOR_INVERT_NODE(parent->e[0]))) 
        {
          res = 1;
          break;
        }
      } 
      else 
      {
        assert (BTOR_REAL_ADDR_NODE (parent->e[0]) != real &&
                BTOR_REAL_ADDR_NODE (parent->e[1]) != real);
      }        
    }        
  }
  return res;
}

int
boolector_fixed_exp_at(Btor* btor, BoolectorNode * node, int pos) 
{
  BtorNode * exp, * simp, * real;
  exp = BTOR_IMPORT_BOOLECTOR_NODE (node);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  BTOR_ABORT_ARG_NULL_BOOLECTOR (exp);
  BTOR_ABORT_REFS_NOT_POS_BOOLECTOR (exp);
  BTOR_ABORT_IF_BTOR_DOES_NOT_MATCH (btor, exp);
  //TODO API check pos
  simp = btor_simplify_exp (btor, exp);
  real = BTOR_REAL_ADDR_NODE (simp);
  assert (real);
  
  return btor_fixed_exp_at(btor, real, pos);
}

size_t
boolector_bytes(Btor* btor){
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  return btor->mm->allocated + btor->mm->sat_allocated;  
}


double 
boolector_get_sat_time(Btor* btor)
{
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  return btor->time.satwc;
}

void
boolector_disable_sat_inc_required (Btor* btor)
{
  BtorAIGMgr *amgr;
  BtorSATMgr *smgr;
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  
  amgr = btor_get_aig_mgr_aigvec_mgr (btor->avmgr);
  smgr = btor_get_sat_mgr_aig_mgr (amgr);
  if (!btor_is_initialized_sat (smgr))
    btor_init_sat(smgr);
  
  smgr->inc_required = 0;
}

void
boolector_set_term_sat (Btor* btor, int (*term)(void*))
{
  BtorAIGMgr *amgr;
  BtorSATMgr *smgr;
  BTOR_ABORT_ARG_NULL_BOOLECTOR (btor);
  
  amgr = btor_get_aig_mgr_aigvec_mgr (btor->avmgr);
  smgr = btor_get_sat_mgr_aig_mgr (amgr);
  
  smgr->term = term;
}

