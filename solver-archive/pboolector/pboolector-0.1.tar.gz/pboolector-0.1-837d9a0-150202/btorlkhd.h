/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */

#ifndef BTOR_LKHD_H_INCLUDED
#define BTOR_LKHD_H_INCLUDED

#include "btorexp.h" 


// return a lookahead node
BtorNode *
btor_lkhd (Btor * btor, int v, int type, int probe, 
            BtorPtrHashTable * remset);

// return a lookahead node simple dummy lookahead for debugging
BtorNode *
btor_lkhd_dummy (Btor * btor, int v, int type, int probe,
                 BtorPtrHashTable * remset);

// return a lookahead node simple dummy lookahead for debugging
BtorNode *
btor_lkhd_simple (Btor * btor);

// apply failed literal reduction
int 
btor_fl_reduction(Btor * btor, int v, int *fl); //failed literal reduction

#endif
