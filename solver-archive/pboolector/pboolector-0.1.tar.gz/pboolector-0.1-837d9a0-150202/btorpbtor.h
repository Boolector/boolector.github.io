/*  Boolector: Satisfiablity Modulo Theories (SMT) solver.
 *
 *  Copyright (C) 2013-2014 Christian Reisenberger.
 *
 *  All rights reserved.
 *
 *  This file is part of Boolector.
 *  See COPYING for more information on using this software.
 */
#ifndef PBTOR_H_INCLUDED
#define PBTOR_H_INCLUDED

#include "btorcore.h"
#include "btorexp.h"

int btor_fixed_exp_at (Btor * btor, BtorNode * exp, int pos);

#endif
